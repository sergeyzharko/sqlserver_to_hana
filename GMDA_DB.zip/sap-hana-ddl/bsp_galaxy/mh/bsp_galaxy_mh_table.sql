/* DDL FOR mh.dim_local_currency_panel */
CREATE TABLE "tgt::mh.dim_local_currency_panel"(
  "local_currency_panel_id" SMALLINT NOT NULL,
  "panel" NVARCHAR(50) NOT NULL,
  "iso_currency_code" NVARCHAR(10) NOT NULL,
  "currency_name" NVARCHAR(50) NOT NULL
);

ALTER TABLE "tgt::mh.dim_local_currency_panel" ADD CONSTRAINT PK_tgt_mh_dim_local_currency_panel PRIMARY KEY ("local_currency_panel_id");

/* DDL FOR mh.dim_target_currency */
CREATE TABLE "tgt::mh.dim_target_currency"(
  "target_currency_id" SMALLINT NOT NULL,
  "iso_currency_code" NVARCHAR(10) NOT NULL,
  "currency_name" NVARCHAR(50) NOT NULL,
  "type" NVARCHAR(10) NOT NULL,
  "sort" INT NOT NULL
);

/* DDL FOR mh.fact_exrate_eur_to_target */
CREATE TABLE "tgt::mh.fact_exrate_eur_to_target"(
  "target_currency_id" SMALLINT NOT NULL,
  "iso_currency_code" NVARCHAR(10) NOT NULL,
  "qtr_id" INT NOT NULL,
  "rate" DECIMAL(24,6) NULL,
  "rate_prev_year" DECIMAL(24,6) NULL
);

ALTER TABLE "tgt::mh.fact_exrate_eur_to_target" ADD CONSTRAINT PK_tgt_mh_fact_exrate_eur_to_target PRIMARY KEY ("target_currency_id", "qtr_id");

/* DDL FOR mh.fact_exrate_lc_to_const_target */
CREATE TABLE "tgt::mh.fact_exrate_lc_to_const_target"(
  "local_currency_panel_id" SMALLINT NOT NULL,
  "target_currency_id" SMALLINT NOT NULL,
  "rate" DECIMAL(24,6) NULL
);

ALTER TABLE "tgt::mh.fact_exrate_lc_to_const_target" ADD CONSTRAINT PK_tgt_mh_fact_exrate_lc_to_const_target PRIMARY KEY ("local_currency_panel_id", "target_currency_id");

/* DDL FOR mh.fact_exrate_lc_to_target */
CREATE TABLE "tgt::mh.fact_exrate_lc_to_target"(
  "local_currency_panel_id" SMALLINT NOT NULL,
  "target_currency_id" SMALLINT NOT NULL,
  "qtr_id" INT NOT NULL,
  "rate_prev_year" DECIMAL(24,6) NULL,
  "rate_diff_vs_prev_year" DECIMAL(24,6) NULL
);

ALTER TABLE "tgt::mh.fact_exrate_lc_to_target" ADD CONSTRAINT PK_tgt_mh_fact_exrate_lc_to_target PRIMARY KEY ("local_currency_panel_id", "target_currency_id", "qtr_id");

/* DDL FOR mh.fact_sal_qtr */
CREATE TABLE "tgt::mh.fact_sal_qtr"(
  "current_all_pack_id" BIGINT NOT NULL,
  "qtr_id" INT NOT NULL,
  "pack_id" BIGINT NOT NULL,
  "current_all_mol_list_id" INT NULL,
  "mol_list_id" INT NULL,
  "local_currency_id" SMALLINT NULL,
  "local_currency_cty_id" SMALLINT NOT NULL,
  "new_prd_pack_id" INT NULL,
  "statistic_id" INT NOT NULL,
  "sal_mnf_eur" DECIMAL(24,6) NULL,
  "sal_mnf_eur_exrate_prev_year" DECIMAL(24,6) NULL,
  "sal_mnf_lc" DECIMAL(24,6) NULL,
  "sal_mnf_eur_internal" DECIMAL(24,6) NULL,
  "sal_mnf_eur_internal_prev_year" DECIMAL(24,6) NULL,
  "un" DECIMAL(24,6) NOT NULL,
  "cu" DECIMAL(24,6) NOT NULL,
  "su" DECIMAL(24,6) NOT NULL,
  "patient_month" DECIMAL(24,6) NULL,
  "egac_price_diff_eur" DECIMAL(24,6) NULL,
  "egac_price_diff_lc" DECIMAL(24,6) NULL,
  "egac_price_diff_eur_internal" DECIMAL(24,6) NULL,
  "egac_vol_diff_eur" DECIMAL(24,6) NULL,
  "egac_vol_diff_lc" DECIMAL(24,6) NULL,
  "egac_vol_diff_eur_internal" DECIMAL(24,6) NULL,
  "period_type" NVARCHAR(10) NULL,
  "source_code" NVARCHAR(5) NOT NULL
);

ALTER TABLE "tgt::mh.fact_sal_qtr" ADD CONSTRAINT PK_tgt_mh_fact_sal_qtr PRIMARY KEY ("current_all_pack_id", "qtr_id");

/* DDL FOR mh.t_check_ProductGroup_market_def_mh */
CREATE TABLE "tgt::mh.t_check_product_group_market_def_mh"(
  "flag" NVARCHAR(100) NOT NULL,
  "product_group_def" NVARCHAR(100) NOT NULL,
  "product_group_data" NVARCHAR(100) NOT NULL,
  "cnt" INT NOT NULL
);