/* DDL FOR wh.dim_local_currency_panel */
CREATE TABLE "tgt::wh.dim_local_currency_panel"(
  "local_currency_panel_id" SMALLINT NOT NULL,
  "panel" NVARCHAR(50) NOT NULL,
  "iso_currency_code" NVARCHAR(10) NOT NULL,
  "currency_name" NVARCHAR(50) NOT NULL
);

ALTER TABLE "tgt::wh.dim_local_currency_panel" ADD CONSTRAINT PK_tgt_wh_dim_local_currency_panel PRIMARY KEY ("local_currency_panel_id");

/* DDL FOR wh.dim_target_currency */
CREATE TABLE "tgt::wh.dim_target_currency"(
  "target_currency_id" SMALLINT NOT NULL,
  "iso_currency_code" NVARCHAR(10) NOT NULL,
  "currency_name" NVARCHAR(50) NOT NULL,
  "type" NVARCHAR(10) NOT NULL,
  "sort" INT NOT NULL
);

/* DDL FOR wh.fact_exrate_eur_to_target */
CREATE TABLE "tgt::wh.fact_exrate_eur_to_target"(
  "target_currency_id" SMALLINT NOT NULL,
  "iso_currency_code" NVARCHAR(10) NOT NULL,
  "qtr_id" INT NOT NULL,
  "rate" DECIMAL(24,6) NULL,
  "rate_prev_year" DECIMAL(24,6) NULL
);

ALTER TABLE "tgt::wh.fact_exrate_eur_to_target" ADD CONSTRAINT PK_tgt_wh_fact_exrate_eur_to_target PRIMARY KEY ("target_currency_id", "qtr_id");

/* DDL FOR wh.fact_exrate_lc_to_const_target */
CREATE TABLE "tgt::wh.fact_exrate_lc_to_const_target"(
  "local_currency_panel_id" SMALLINT NOT NULL,
  "target_currency_id" SMALLINT NOT NULL,
  "rate" DECIMAL(24,6) NULL
);

ALTER TABLE "tgt::wh.fact_exrate_lc_to_const_target" ADD CONSTRAINT PK_tgt_wh_fact_exrate_lc_to_const_target PRIMARY KEY ("local_currency_panel_id", "target_currency_id");

/* DDL FOR wh.fact_exrate_lc_to_target */
CREATE TABLE "tgt::wh.fact_exrate_lc_to_target"(
  "local_currency_panel_id" SMALLINT NOT NULL,
  "target_currency_id" SMALLINT NOT NULL,
  "qtr_id" INT NOT NULL,
  "rate_prev_year" DECIMAL(24,6) NULL,
  "rate_diff_vs_prev_year" DECIMAL(24,6) NULL
);

ALTER TABLE "tgt::wh.fact_exrate_lc_to_target" ADD CONSTRAINT PK_tgt_wh_fact_exrate_lc_to_target PRIMARY KEY ("local_currency_panel_id", "target_currency_id", "qtr_id");

/* DDL FOR wh.fact_sal_qtr */
CREATE TABLE "tgt::wh.fact_sal_qtr"(
  "current_all_pack_id" BIGINT NOT NULL,
  "qtr_id" INT NOT NULL,
  "pack_id" BIGINT NOT NULL,
  "current_all_mol_list_id" INT NULL,
  "mol_list_id" INT NULL,
  "local_currency_id" SMALLINT NULL,
  "local_currency_cty_id" SMALLINT NOT NULL,
  "new_prd_pack_id" INT NULL,
  "statistic_id" INT NOT NULL,
  "sal_eur_mnf" DECIMAL(24,6) NULL,
  "sal_lc_mnf" DECIMAL(24,6) NULL,
  "sal_eur_mnf_exrate_prev_year" DECIMAL(24,6) NULL,
  "sal_eur_int_exrate" DECIMAL(24,6) NULL,
  "sal_eur_int_exrate_prev_year" DECIMAL(24,6) NULL,
  "discounted_sal_eur_mnf" DECIMAL(24,6) NULL,
  "discounted_sal_lc_mnf" DECIMAL(24,6) NULL,
  "discounted_sal_eur_exrate_prev_year" DECIMAL(24,6) NULL,
  "discounted_sal_eur_int_exrate" DECIMAL(24,6) NULL,
  "discounted_sal_eur_int_exrate_prev_year" DECIMAL(24,6) NULL,
  "un" DECIMAL(24,6) NOT NULL,
  "cu" DECIMAL(24,6) NOT NULL,
  "su" DECIMAL(24,6) NOT NULL,
  "cycles" DECIMAL(24,6) NULL,
  "cycles_sahc" DECIMAL(24,6) NULL,
  "egac_price_diff_eur" DECIMAL(24,6) NULL,
  "egac_price_diff_lc" DECIMAL(24,6) NULL,
  "egac_price_diff_int_exrate" DECIMAL(24,6) NULL,
  "egac_vol_diff_eur" DECIMAL(24,6) NULL,
  "egac_vol_diff_lc" DECIMAL(24,6) NULL,
  "egac_vol_diff_int_exrate" DECIMAL(24,6) NULL,
  "egac_price_diff_eur_discounted" DECIMAL(24,6) NULL,
  "egac_price_diff_lc_discounted" DECIMAL(24,6) NULL,
  "egac_price_diff_int_exrate_discounted" DECIMAL(24,6) NULL,
  "egac_vol_diff_eur_discounted" DECIMAL(24,6) NULL,
  "egac_vol_diff_lc_discounted" DECIMAL(24,6) NULL,
  "egac_vol_diff_int_exrate_discounted" DECIMAL(24,6) NULL,
  "period_type" NVARCHAR(10) NULL,
  "source_code" NVARCHAR(5) NOT NULL
);

ALTER TABLE "tgt::wh.fact_sal_qtr" ADD CONSTRAINT PK_tgt_wh_fact_sal_qtr PRIMARY KEY ("current_all_pack_id", "qtr_id");

/* DDL FOR wh.t_check_ProductGroup_market_def_wh */
CREATE TABLE "tgt::wh.t_check_product_group_market_def_wh"(
  "flag" NVARCHAR(100) NOT NULL,
  "product_group_def" NVARCHAR(100) NOT NULL,
  "product_group_data" NVARCHAR(100) NOT NULL,
  "cnt" INT NOT NULL
);