/* DDL FOR general.dim_new_prd_pack_qtr */
CREATE TABLE "tgt::general.dim_new_prd_pack_qtr"(
  "new_prd_pack_id" INT NOT NULL,
  "new_in_last_4_qtrs" NVARCHAR(10) NOT NULL,
  "new_in_last_3_qtrs" NVARCHAR(10) NOT NULL,
  "new_in_last_2_qtrs" NVARCHAR(10) NOT NULL,
  "new_in_last_1_qtrs" NVARCHAR(10) NOT NULL
);

ALTER TABLE "tgt::general.dim_new_prd_pack_qtr" ADD CONSTRAINT PK_tgt_general_dim_new_prd_pack_qtr PRIMARY KEY ("new_prd_pack_id");

/* DDL FOR general.dim_statistic */
CREATE TABLE "tgt::general.dim_statistic"(
  "statistic_id" INT NOT NULL,
  "name" NVARCHAR(255) NOT NULL,
  "pars_statistic_type" NVARCHAR(50) NOT NULL,
  "unique_name" NVARCHAR(50) NOT NULL,
  "period_dist" INT NOT NULL,
  "period_dist_unit" NVARCHAR(10) NULL,
  "format" NVARCHAR(50) NULL,
  "sort" INT NOT NULL,
  "display_folder" NVARCHAR(255) NULL,
  "reference_base" NVARCHAR(255) NULL
);

ALTER TABLE "tgt::general.dim_statistic" ADD CONSTRAINT PK_tgt_general_dim_statistic PRIMARY KEY ("statistic_id");