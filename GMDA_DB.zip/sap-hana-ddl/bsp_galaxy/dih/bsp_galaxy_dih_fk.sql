/* DDL FOR dih.t_fact_AMR_nm */
ALTER TABLE "tgt::dih.t_fact_amr_nm" ADD CONSTRAINT "FK_tgt_dih_t_fact_amr_nm_t_fact_amr_nm_upd_six_id" FOREIGN KEY ("upd_six_id") REFERENCES "tgt::dih.t_dim_amr_upd_six"("upd_six_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR dih.t_fact_AMR_pack */
ALTER TABLE "tgt::dih.t_fact_amr_pack" ADD CONSTRAINT "FK_tgt_dih_t_fact_amr_pack_t_fact_amr_pack_upd_six_id" FOREIGN KEY ("upd_six_id") REFERENCES "tgt::dih.t_dim_amr_upd_six"("upd_six_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR dih.t_fact_AMR_patient_volume */
ALTER TABLE "tgt::dih.t_fact_amr_patient_volume" ADD CONSTRAINT "FK_tgt_dih_t_fact_amr_patient_volume_t_fact_amr_patient_volume_upd_six_id" FOREIGN KEY ("upd_six_id") REFERENCES "tgt::dih.t_dim_amr_upd_six"("upd_six_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR dih.t_fact_AMR_proc_volume_w_contrast */
ALTER TABLE "tgt::dih.t_fact_amr_proc_volume_w_contrast" ADD CONSTRAINT "FK_tgt_dih_t_fact_amr_proc_volume_w_contrast_t_fact_amr_proc_volume_w_contrast_upd_six_id" FOREIGN KEY ("upd_six_id") REFERENCES "tgt::dih.t_dim_amr_upd_six"("upd_six_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR dih.t_fact_AMR_proc_volume_wo_contrast */
ALTER TABLE "tgt::dih.t_fact_amr_proc_volume_wo_contrast" ADD CONSTRAINT "FK_tgt_dih_t_fact_amr_proc_volume_wo_contrast_t_fact_amr_proc_volume_wo_contrast_upd_six_id" FOREIGN KEY ("upd_six_id") REFERENCES "tgt::dih.t_dim_amr_upd_six"("upd_six_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



