/* DDL FOR bak.G945_SHYEC_current_all__dim_local_currency_panel_20190306 */
CREATE TABLE "tgt::bak.g945_shyec_current_all__dim_local_currency_panel_20190306"(
  "local_currency_panel_id" SMALLINT NOT NULL,
  "panel" NVARCHAR(50) NOT NULL,
  "iso_currency_code" NVARCHAR(10) NOT NULL,
  "currency_name" NVARCHAR(50) NOT NULL
);

/* DDL FOR bak.G945_SHYEC_current_all__dim_target_currency_20190306 */
CREATE TABLE "tgt::bak.g945_shyec_current_all__dim_target_currency_20190306"(
  "target_currency_id" SMALLINT NOT NULL,
  "iso_currency_code" NVARCHAR(10) NOT NULL,
  "currency_name" NVARCHAR(50) NOT NULL,
  "type" NVARCHAR(10) NOT NULL,
  "sort" INT NOT NULL
);

/* DDL FOR bak.G945_SHYEC_current_all__fact_exrate_eur_to_target_20190306 */
CREATE TABLE "tgt::bak.g945_shyec_current_all__fact_exrate_eur_to_target_20190306"(
  "target_currency_id" SMALLINT NOT NULL,
  "iso_currency_code" NVARCHAR(10) NOT NULL,
  "qtr_id" INT NOT NULL,
  "rate" DECIMAL(24,6) NULL,
  "rate_prev_year" DECIMAL(24,6) NULL
);

/* DDL FOR bak.G945_SHYEC_mh__dim_local_currency_panel_20190306 */
CREATE TABLE "tgt::bak.g945_shyec_mh__dim_local_currency_panel_20190306"(
  "local_currency_panel_id" SMALLINT NOT NULL,
  "panel" NVARCHAR(50) NOT NULL,
  "iso_currency_code" NVARCHAR(10) NOT NULL,
  "currency_name" NVARCHAR(50) NOT NULL
);

/* DDL FOR bak.G945_SHYEC_mh__dim_target_currency_20190306 */
CREATE TABLE "tgt::bak.g945_shyec_mh__dim_target_currency_20190306"(
  "target_currency_id" SMALLINT NOT NULL,
  "iso_currency_code" NVARCHAR(10) NOT NULL,
  "currency_name" NVARCHAR(50) NOT NULL,
  "type" NVARCHAR(10) NOT NULL,
  "sort" INT NOT NULL
);

/* DDL FOR bak.G945_SHYEC_mh__fact_exrate_eur_to_target_20190306 */
CREATE TABLE "tgt::bak.g945_shyec_mh__fact_exrate_eur_to_target_20190306"(
  "target_currency_id" SMALLINT NOT NULL,
  "iso_currency_code" NVARCHAR(10) NOT NULL,
  "qtr_id" INT NOT NULL,
  "rate" DECIMAL(24,6) NULL,
  "rate_prev_year" DECIMAL(24,6) NULL
);

/* DDL FOR bak.G945_SHYEC_wh__dim_local_currency_panel_20190306 */
CREATE TABLE "tgt::bak.g945_shyec_wh__dim_local_currency_panel_20190306"(
  "local_currency_panel_id" SMALLINT NOT NULL,
  "panel" NVARCHAR(50) NOT NULL,
  "iso_currency_code" NVARCHAR(10) NOT NULL,
  "currency_name" NVARCHAR(50) NOT NULL
);

/* DDL FOR bak.G945_SHYEC_wh__dim_target_currency_20190306 */
CREATE TABLE "tgt::bak.g945_shyec_wh__dim_target_currency_20190306"(
  "target_currency_id" SMALLINT NOT NULL,
  "iso_currency_code" NVARCHAR(10) NOT NULL,
  "currency_name" NVARCHAR(50) NOT NULL,
  "type" NVARCHAR(10) NOT NULL,
  "sort" INT NOT NULL
);

/* DDL FOR bak.G945_SHYEC_wh__fact_exrate_eur_to_target_20190306 */
CREATE TABLE "tgt::bak.g945_shyec_wh__fact_exrate_eur_to_target_20190306"(
  "target_currency_id" SMALLINT NOT NULL,
  "iso_currency_code" NVARCHAR(10) NOT NULL,
  "qtr_id" INT NOT NULL,
  "rate" DECIMAL(24,6) NULL,
  "rate_prev_year" DECIMAL(24,6) NULL
);