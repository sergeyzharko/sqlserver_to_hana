/* DDL FOR cam.fact_promo_exrates_eur_to_target */
ALTER TABLE "tgt::cam.fact_promo_exrates_eur_to_target" ADD CONSTRAINT "FK_tgt_cam_fact_promo_exrates_eur_to_target_quarter_id" FOREIGN KEY ("quarter_id") REFERENCES "tgt::cam.dim_promo_period"("quarter_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "tgt::cam.fact_promo_exrates_eur_to_target" ADD CONSTRAINT "FK_tgt_cam_fact_promo_exrates_eur_to_target_target_currency_id" FOREIGN KEY ("target_currency_id") REFERENCES "tgt::cam.dim_promo_target_currency"("target_currency_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR cam.fact_promo_exrates_lc_to_const_target */
ALTER TABLE "tgt::cam.fact_promo_exrates_lc_to_const_target" ADD CONSTRAINT "FK_tgt_cam_fact_promo_exrates_lc_to_const_target_local_currency_id" FOREIGN KEY ("local_currency_id") REFERENCES "tgt::cam.dim_promo_local_currency"("local_currency_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "tgt::cam.fact_promo_exrates_lc_to_const_target" ADD CONSTRAINT "FK_tgt_cam_fact_promo_exrates_lc_to_const_target_target_currency_id" FOREIGN KEY ("target_currency_id") REFERENCES "tgt::cam.dim_promo_target_currency"("target_currency_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR cam.fact_promo_promo */
ALTER TABLE "tgt::cam.fact_promo_promo" ADD CONSTRAINT "FK_tgt_cam_fact_promo_promo_local_currency_id" FOREIGN KEY ("local_currency_id") REFERENCES "tgt::cam.dim_promo_local_currency"("local_currency_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "tgt::cam.fact_promo_promo" ADD CONSTRAINT "FK_tgt_cam_fact_promo_promo_quarter_id" FOREIGN KEY ("quarter_id") REFERENCES "tgt::cam.dim_promo_period"("quarter_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "tgt::cam.fact_promo_promo" ADD CONSTRAINT "FK_tgt_cam_fact_promo_promo_product_id" FOREIGN KEY ("product_id") REFERENCES "tgt::cam.dim_promo_product"("product_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "tgt::cam.fact_promo_promo" ADD CONSTRAINT "FK_tgt_cam_fact_promo_promo_promotion_id" FOREIGN KEY ("promotion_id") REFERENCES "tgt::cam.dim_promo_promotion"("promotion_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR cam.fact_sfr_sfr */
ALTER TABLE "tgt::cam.fact_sfr_sfr" ADD CONSTRAINT "FK_tgt_cam_fact_sfr_sfr_mat_id" FOREIGN KEY ("mat_id") REFERENCES "tgt::cam.dim_sfr_period"("mat_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "tgt::cam.fact_sfr_sfr" ADD CONSTRAINT "FK_tgt_cam_fact_sfr_sfr_sfr_id" FOREIGN KEY ("sfr_id") REFERENCES "tgt::cam.dim_sfr_sfr"("sfr_id") ON DELETE RESTRICT ON UPDATE RESTRICT;