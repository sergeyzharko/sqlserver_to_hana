/* DDL FOR dataone.DataOneMappedData */
CREATE TABLE "tgt::dataone.dataone_mapped_data"(
  "qtr_id" INT NULL,
  "country_of_fd" NVARCHAR(3) NULL,
  "grace_cty" NVARCHAR(50) NULL,
  "prctr" NVARCHAR(10) NULL,
  "dataone_prd" NVARCHAR(50) NULL,
  "grace_prd" NVARCHAR(50) NULL,
  "value_gc" NUMERIC(38,7) NULL,
  "qty_bas" NUMERIC(38,7) NULL,
  "qty_auom" NUMERIC(38,7) NULL
);

/* DDL FOR dataone.GRACE_QTR */
CREATE TABLE "tgt::dataone.grace_qtr"(
  "qtr_id" INT NULL,
  "default_panel_current_all" NVARCHAR(50) NULL,
  "source_code" NVARCHAR(10) NULL,
  "commercial_operation" NVARCHAR(100) NULL,
  "country" NVARCHAR(100) NULL,
  "intprd_corrected" NVARCHAR(100) NULL,
  "mkt_type" NVARCHAR(100) NULL,
  "un" DECIMAL(24,6) NULL,
  "su" DECIMAL(24,6) NULL,
  "sal_eur_mnf" DECIMAL(24,6) NULL
);

/* DDL FOR dataone.period */
CREATE TABLE "tgt::dataone.period"(
  "qtr_id" INT NULL,
  "quarter" NVARCHAR(35) NULL,
  "quarter_valid" NVARCHAR(50) NULL,
  "six_id" INT NULL,
  "six" NVARCHAR(35) NULL,
  "six_valid" NVARCHAR(50) NULL,
  "year_id" INT NULL,
  "year" NVARCHAR(32) NULL,
  "year_valid" NVARCHAR(50) NULL,
  "mat" NVARCHAR(20) NULL,
  "mat_valid" NVARCHAR(50) NULL
);
