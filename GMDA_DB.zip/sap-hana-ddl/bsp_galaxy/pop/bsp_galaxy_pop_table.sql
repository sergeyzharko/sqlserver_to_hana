/* DDL FOR pop.dim_age */
CREATE TABLE "tgt::pop.dim_age"(
  "age_id" INT NOT NULL,
  "age" NVARCHAR(40) NULL
);

ALTER TABLE "tgt::pop.dim_age" ADD CONSTRAINT PK_tgt_pop_dim_age PRIMARY KEY ("age_id");

/* DDL FOR pop.dim_geo */
CREATE TABLE "tgt::pop.dim_geo"(
  "country_id" BIGINT NOT NULL,
  "region" NVARCHAR(100) NULL,
  "region_order" BIGINT NULL,
  "region_order_orig" INT NULL,
  "region_short_name" NVARCHAR(30) NULL,
  "subregion" NVARCHAR(100) NULL,
  "subregion_order" BIGINT NULL,
  "subregion_order_orig" INT NULL,
  "subregion_short_name" NVARCHAR(30) NULL,
  "country_group" NVARCHAR(100) NULL,
  "country_group_order" BIGINT NULL,
  "country_group_order_orig" INT NULL,
  "country_group_short" NVARCHAR(30) NULL,
  "country" NVARCHAR(100) NULL,
  "country_order" BIGINT NULL,
  "country_order_orig" INT NULL,
  "country_short" NVARCHAR(30) NULL,
  "direct_reporting_country" INT NULL,
  "commercial_operation" NVARCHAR(100) NULL,
  "commercial_operation_short_name" NVARCHAR(30) NOT NULL DEFAULT '*not assigned*',
  "commercial_operation_order_orig" INT NOT NULL DEFAULT -1,
  "commercial_operation_order" BIGINT NOT NULL DEFAULT -1
);

ALTER TABLE "tgt::pop.dim_geo" ADD CONSTRAINT PK_tgt_pop_dim_geo PRIMARY KEY ("country_id");

/* DDL FOR pop.dim_period */
CREATE TABLE "tgt::pop.dim_period"(
  "year_id" INT NOT NULL,
  "year" NVARCHAR(6) NULL
);

ALTER TABLE "tgt::pop.dim_period" ADD CONSTRAINT PK_tgt_pop_dim_period PRIMARY KEY ("year_id");

/* DDL FOR pop.dim_sex */
CREATE TABLE "tgt::pop.dim_sex"(
  "sex_id" INT NOT NULL,
  "sex" NVARCHAR(50) NULL
);

ALTER TABLE "tgt::pop.dim_sex" ADD CONSTRAINT PK_tgt_pop_dim_sex PRIMARY KEY ("sex_id");

/* DDL FOR pop.fact_population */
CREATE TABLE "tgt::pop.fact_population"(
  "fact_id" INT NOT NULL,
  "country_id" BIGINT NULL,
  "age_id" INT NULL,
  "year_id" INT NULL,
  "sex_id" INT NULL,
  "population" BIGINT NULL,
  "statistic_id" INT NULL
);

ALTER TABLE "tgt::pop.fact_population" ADD CONSTRAINT PK_tgt_pop_fact_population PRIMARY KEY ("fact_id");