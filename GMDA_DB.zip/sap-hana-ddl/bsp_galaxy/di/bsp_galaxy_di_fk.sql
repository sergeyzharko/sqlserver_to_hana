/* WARNING! PAY ATTENTION THAT THE TABLE HAS INDEXES */
/* DDL FOR di.MRG_currency_rates */
ALTER TABLE "tgt::di.mrg_currency_rates" ADD CONSTRAINT "FK_tgt_di_mrg_currency_rates_mrg_currency_rates_local_currency_id" FOREIGN KEY ("local_currency_id") REFERENCES "tgt::di.mrg_currencies"("currency_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "tgt::di.mrg_currency_rates" ADD CONSTRAINT "FK_tgt_di_mrg_currency_rates_mrg_currency_rates_target_currency_id" FOREIGN KEY ("target_currency_id") REFERENCES "tgt::di.mrg_currencies"("currency_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR di.MRG_facts */
ALTER TABLE "tgt::di.mrg_facts" ADD CONSTRAINT "FK_tgt_di_mrg_facts_mrg_facts_entry_id" FOREIGN KEY ("entry_id") REFERENCES "tgt::di.mrg_entries"("entry_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "tgt::di.mrg_facts" ADD CONSTRAINT "FK_tgt_di_mrg_facts_mrg_facts_period_id" FOREIGN KEY ("period_id") REFERENCES "tgt::di.mrg_period"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;