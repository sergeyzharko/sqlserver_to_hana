/* DDL FOR gers.maint_CRP_lookup */
ALTER TABLE "stg::gers.maint_crp_lookup" ADD CONSTRAINT "FK_stg_gers_maint_crp_lookup_maint_crp_lookup_maint_crp_list_id" FOREIGN KEY ("maint_crp_list_id") REFERENCES "stg::gers.maint_crp_list"("maint_crp_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR gers.maint_MNF */
ALTER TABLE "stg::gers.maint_mnf" ADD CONSTRAINT "FK_stg_gers_maint_mnf_maint_mnf_maint_crp_list_id" FOREIGN KEY ("maint_crp_list_id") REFERENCES "stg::gers.maint_crp_list"("maint_crp_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR gers.maint_Mol_lookup */
ALTER TABLE "stg::gers.maint_mol_lookup" ADD CONSTRAINT "FK_stg_gers_maint_mol_lookup_maint_mol_lookup_maint_mol_list_id" FOREIGN KEY ("maint_mol_list_id") REFERENCES "stg::gers.maint_mol_list"("maint_mol_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR gers.maint_Pack */
ALTER TABLE "stg::gers.maint_pack" ADD CONSTRAINT "FK_stg_gers_maint_pack_maint_pack_maint_atc4_lookup_id" FOREIGN KEY ("maint_atc4_lookup_id") REFERENCES "stg::gers.maint_atc4_lookup"("maint_atc4_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::gers.maint_pack" ADD CONSTRAINT "FK_stg_gers_maint_pack_maint_pack_maint_intpck_lookup_id" FOREIGN KEY ("maint_intpck_lookup_id") REFERENCES "stg::gers.maint_intpck_lookup"("maint_intpck_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::gers.maint_pack" ADD CONSTRAINT "FK_stg_gers_maint_pack_maint_pack_maint_intprod_lookup_id" FOREIGN KEY ("maint_intprod_lookup_id") REFERENCES "stg::gers.maint_intprod_lookup"("maint_intprod_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::gers.maint_pack" ADD CONSTRAINT "FK_stg_gers_maint_pack_maint_pack_maint_intstr_lookup_id" FOREIGN KEY ("maint_intstr_lookup_id") REFERENCES "stg::gers.maint_intstr_lookup"("maint_intstr_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::gers.maint_pack" ADD CONSTRAINT "FK_stg_gers_maint_pack_maint_pack_maint_mol_list_id" FOREIGN KEY ("maint_mol_list_id") REFERENCES "stg::gers.maint_mol_list"("maint_mol_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::gers.maint_pack" ADD CONSTRAINT "FK_stg_gers_maint_pack_maint_pack_maint_nfc_lookup_id" FOREIGN KEY ("maint_nfc_lookup_id") REFERENCES "stg::gers.maint_nfc_lookup"("maint_nfc_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::gers.maint_pack" ADD CONSTRAINT "FK_stg_gers_maint_pack_maint_pack_maint_subsegment_lookup_id" FOREIGN KEY ("maint_subsegment_lookup_id") REFERENCES "stg::gers.maint_subsegment_lookup"("maint_subsegment_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::gers.maint_pack" ADD CONSTRAINT "FK_stg_gers_maint_pack_maint_pack_maint_su_factor_lookup_id" FOREIGN KEY ("maint_su_factor_lookup_id") REFERENCES "stg::gers.maint_su_factor_lookup"("maint_su_factor_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR gers.maint_Product_lookup */
ALTER TABLE "stg::gers.maint_product_lookup" ADD CONSTRAINT "FK_stg_gers_maint_product_lookup_maint_product_lookup_maint_mol_list_id" FOREIGN KEY ("maint_mol_list_id") REFERENCES "stg::gers.maint_mol_list"("maint_mol_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
