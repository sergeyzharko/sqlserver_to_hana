/* DDL FOR ims_ab.bridge_Mol_to_Mol_List */
CREATE TABLE "stg::ims_ab.bridge_mol_to_mol_list"(
  "mol_id" INT NOT NULL,
  "mol_list_id" INT NOT NULL
);

ALTER TABLE "stg::ims_ab.bridge_mol_to_mol_list" ADD CONSTRAINT PK_stg_ims_ab_bridge_mol_to_mol_list PRIMARY KEY ("mol_id", "mol_list_id");



/* DDL FOR ims_ab.dataview_fact */
CREATE TABLE "stg::ims_ab.dataview_fact"(
  "period" INT NULL,
  "cty" INT NULL,
  "crp" INT NULL,
  "mnf" INT NULL,
  "mnf_own" INT NULL,
  "atc4" INT NULL,
  "intprd" INT NULL,
  "intprd_cty" INT NULL,
  "intprd_ldate" NVARCHAR(7) NULL,
  "prd" INT NULL,
  "prd_mnf" INT NULL,
  "prd_ldate" NVARCHAR(7) NULL,
  "nfc123" INT NULL,
  "str" INT NULL,
  "diag4" INT NULL,
  "mol" INT NULL,
  "mol_cty" INT NULL,
  "mol_crp" INT NULL,
  "mol_ldate" NVARCHAR(7) NULL,
  "dc0" INT NULL,
  "rx" DECIMAL(24,6) NULL,
  "from_hist_id" INT NULL
);



/* DDL FOR ims_ab.dataview_fact_hist_intermediate */
CREATE TABLE "stg::ims_ab.dataview_fact_hist_intermediate"(
  "hist_id" INT NOT NULL,
  "period" INT NULL,
  "period_lookup_hist_id" INT NULL,
  "cty" INT NULL,
  "cty_lookup_hist_id" INT NULL,
  "crp" INT NULL,
  "crp_lookup_hist_id" INT NULL,
  "mnf" INT NULL,
  "mnf_lookup_hist_id" INT NULL,
  "mnf_own" INT NULL,
  "mnf_own_hist" INT NULL,
  "atc4" INT NULL,
  "atc4_lookup_hist_id" INT NULL,
  "intprd" INT NULL,
  "intprd_lookup_hist_id" INT NULL,
  "intprd_cty" INT NULL,
  "intprd_cty_lookup_hist_id" INT NULL,
  "intprd_ldate" NVARCHAR(7) NULL,
  "intprd_ldate_hist" NVARCHAR(7) NULL,
  "prd" INT NULL,
  "prd_lookup_hist_id" INT NULL,
  "prd_mnf" INT NULL,
  "prd_mnf_lookup_hist_id" INT NULL,
  "prd_ldate" NVARCHAR(7) NULL,
  "prd_ldate_hist" NVARCHAR(7) NULL,
  "nfc123" INT NULL,
  "nfc123_lookup_hist_id" INT NULL,
  "str" INT NULL,
  "str_lookup_hist_id" INT NULL,
  "diag4" INT NULL,
  "diag4_lookup_hist_id" INT NULL,
  "mol" INT NULL,
  "mol_lookup_hist_id" INT NULL,
  "mol_cty" INT NULL,
  "mol_cty_lookup_hist_id" INT NULL,
  "mol_crp" INT NULL,
  "mol_crp_lookup_hist_id" INT NULL,
  "mol_ldate" NVARCHAR(7) NULL,
  "mol_ldate_hist" NVARCHAR(7) NULL,
  "dc0" INT NULL,
  "rx" DECIMAL(24,6) NULL
);



/* DDL FOR ims_ab.dataview_fact_historical */
CREATE TABLE "stg::ims_ab.dataview_fact_historical"(
  "period" INT NULL,
  "cty" INT NULL,
  "crp" INT NULL,
  "mnf" INT NULL,
  "mnf_own" INT NULL,
  "atc4" INT NULL,
  "intprd" INT NULL,
  "intprd_cty" INT NULL,
  "intprd_ldate" NVARCHAR(7) NULL,
  "prd" INT NULL,
  "prd_mnf" INT NULL,
  "prd_ldate" NVARCHAR(7) NULL,
  "nfc123" INT NULL,
  "str" INT NULL,
  "diag4" INT NULL,
  "mol" INT NULL,
  "mol_cty" INT NULL,
  "mol_crp" INT NULL,
  "mol_ldate" NVARCHAR(7) NULL,
  "dc0" INT NULL,
  "rx" DECIMAL(24,6) NULL
);



/* DDL FOR ims_ab.dataview_flat */
CREATE TABLE "stg::ims_ab.dataview_flat"(
  "period_id" INT NOT NULL,
  "dc0" INT NOT NULL,
  "period" NVARCHAR(100) NULL,
  "cty" NVARCHAR(100) NULL,
  "crp" NVARCHAR(100) NULL,
  "mnf" NVARCHAR(100) NULL,
  "mnf_own" INT NULL,
  "atc4" NVARCHAR(100) NULL,
  "intprd" NVARCHAR(100) NULL,
  "intprd_cty" NVARCHAR(100) NULL,
  "intprd_ldate" NVARCHAR(7) NULL,
  "prd" NVARCHAR(100) NULL,
  "prd_mnf" NVARCHAR(100) NULL,
  "prd_ldate" NVARCHAR(7) NULL,
  "nfc123" NVARCHAR(100) NULL,
  "str" NVARCHAR(100) NULL,
  "diag4" NVARCHAR(100) NULL,
  "source_id" NVARCHAR(10) NULL,
  "mol_list" NVARCHAR(4000) NULL,
  "rx" DECIMAL(24,6) NULL,
  "crp_midas" NVARCHAR(100) NULL,
  "mnf_midas" NVARCHAR(100) NULL
);

ALTER TABLE "stg::ims_ab.dataview_flat" ADD CONSTRAINT PK_stg_ims_ab_dataview_flat PRIMARY KEY ("dc0", "period_id");



/* DDL FOR ims_ab.dataview_flat_dv_d2 */
CREATE TABLE "stg::ims_ab.dataview_flat_dv_d2"(
  "period_id" INT NULL,
  "period" NVARCHAR(100) NULL,
  "cty" NVARCHAR(100) NULL,
  "crp" NVARCHAR(100) NULL,
  "mnf" NVARCHAR(100) NULL,
  "mnf_own" INT NULL,
  "atc4" NVARCHAR(100) NULL,
  "intprd" NVARCHAR(100) NULL,
  "intprd_cty" NVARCHAR(100) NULL,
  "intprd_ldate" NVARCHAR(7) NULL,
  "prd" NVARCHAR(100) NULL,
  "prd_mnf" NVARCHAR(100) NULL,
  "prd_ldate" NVARCHAR(7) NULL,
  "nfc123" NVARCHAR(100) NULL,
  "str" NVARCHAR(100) NULL,
  "local_curreny_cty_id" SMALLINT NULL,
  "local_curreny_id" SMALLINT NULL,
  "diag4" NVARCHAR(100) NULL,
  "mol_list" NVARCHAR(4000) NULL,
  "dc0" INT NULL,
  "rx" DECIMAL(24,6) NULL,
  "rxfs" DECIMAL(24,6) NULL,
  "sal_eur_fs" DECIMAL(24,6) NULL,
  "sal_lc_fs" DECIMAL(24,6) NULL,
  "unfs" DECIMAL(24,6) NULL,
  "dv_eur" DECIMAL(24,6) NULL,
  "d2_eur" DECIMAL(24,6) NULL,
  "dv_lc" DECIMAL(24,6) NULL,
  "d2_lc" DECIMAL(24,6) NULL,
  "source_id" NVARCHAR(10) NULL,
  "ssis_task" NVARCHAR(100) NULL,
  "diag4_code" NVARCHAR(10) NULL
);



/* DDL FOR ims_ab.dataview_flat_mol */
CREATE TABLE "stg::ims_ab.dataview_flat_mol"(
  "period_id" INT NULL,
  "period" NVARCHAR(100) NULL,
  "cty" NVARCHAR(100) NULL,
  "crp" NVARCHAR(100) NULL,
  "mnf" NVARCHAR(100) NULL,
  "mnf_own" INT NULL,
  "atc4" NVARCHAR(100) NULL,
  "intprd" NVARCHAR(100) NULL,
  "intprd_cty" NVARCHAR(100) NULL,
  "intprd_ldate" NVARCHAR(7) NULL,
  "prd" NVARCHAR(100) NULL,
  "prd_mnf" NVARCHAR(100) NULL,
  "prd_ldate" NVARCHAR(7) NULL,
  "nfc123" NVARCHAR(100) NULL,
  "str" NVARCHAR(100) NULL,
  "diag4" NVARCHAR(100) NULL,
  "mol" NVARCHAR(100) NULL,
  "mol_cty" NVARCHAR(100) NULL,
  "mol_crp" NVARCHAR(100) NULL,
  "mol_ldate" NVARCHAR(7) NULL,
  "dc0" INT NULL,
  "rx" DECIMAL(24,6) NULL,
  "source_id" NVARCHAR(10) NULL,
  "mol_list" NVARCHAR(4000) NULL
);



/* DDL FOR ims_ab.dataview_lookup */
CREATE TABLE "stg::ims_ab.dataview_lookup"(
  "lookup" VARCHAR(50) NULL,
  "id" INT NULL,
  "name" NVARCHAR(100) NULL
);



/* DDL FOR ims_ab.dataview_lookup_hist_intermediate */
CREATE TABLE "stg::ims_ab.dataview_lookup_hist_intermediate"(
  "hist_id" INT NOT NULL,
  "lookup" VARCHAR(50) NULL,
  "id" INT NULL,
  "name" NVARCHAR(100) NULL,
  "lookup_hist_id" INT NULL,
  "name_hist" NVARCHAR(100) NULL
);



/* DDL FOR ims_ab.dataview_lookup_historical */
CREATE TABLE "stg::ims_ab.dataview_lookup_historical"(
  "lookup" VARCHAR(50) NULL,
  "id" INT NULL,
  "name" NVARCHAR(100) NULL
);



/* DDL FOR ims_ab.dataview_rx_aggregated */
CREATE TABLE "stg::ims_ab.dataview_rx_aggregated"(
  "cty" NVARCHAR(100) NULL,
  "crp" NVARCHAR(100) NULL,
  "mnf" NVARCHAR(100) NULL,
  "atc4" NVARCHAR(100) NULL,
  "prd" NVARCHAR(100) NULL,
  "nfc123" NVARCHAR(100) NULL,
  "str" NVARCHAR(100) NULL,
  "period_id" INT NULL,
  "rx" DECIMAL(24,6) NULL,
  "prd_mnf" NVARCHAR(100) NULL,
  "mnf_own" INT NULL,
  "crp_midas" NVARCHAR(100) NULL,
  "mnf_midas" NVARCHAR(100) NULL
);



/* DDL FOR ims_ab.dataview_sal_aggregated */
CREATE TABLE "stg::ims_ab.dataview_sal_aggregated"(
  "cty" NVARCHAR(100) NULL,
  "crp" NVARCHAR(100) NULL,
  "mnf" NVARCHAR(100) NULL,
  "atc4" NVARCHAR(100) NULL,
  "prd" NVARCHAR(100) NULL,
  "nfc123" NVARCHAR(100) NULL,
  "str" NVARCHAR(100) NULL,
  "local_curreny_cty_id" SMALLINT NULL,
  "local_curreny_id" SMALLINT NULL,
  "period_id" INT NULL,
  "sal_eur_mnf" DECIMAL(24,6) NULL,
  "sal_lc_mnf" DECIMAL(24,6) NULL,
  "un" DECIMAL(24,6) NULL,
  "prd_mnf" NVARCHAR(100) NULL,
  "mnf_own" INT NULL
);



/* DDL FOR ims_ab.excel_indications */
CREATE TABLE "stg::ims_ab.excel_indications"(
  "ind_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "diag4" NVARCHAR(100) NULL,
  "diag4_code" NVARCHAR(4) NULL,
  "ab_indications" NVARCHAR(100) NULL
);



/* DDL FOR ims_ab.ICD_Diagnosis_codes */
CREATE TABLE "stg::ims_ab.icd_diagnosis_codes"(
  "level" INT NULL,
  "code" NVARCHAR(10) NOT NULL,
  "description" NVARCHAR(100) NULL
);

ALTER TABLE "stg::ims_ab.icd_diagnosis_codes" ADD CONSTRAINT PK_stg_ims_ab_icd_diagnosis_codes PRIMARY KEY ("code");



/* DDL FOR ims_ab.load_hist */
CREATE TABLE "stg::ims_ab.load_hist"(
  "hist_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "hist_date" TIMESTAMP NOT NULL
);

ALTER TABLE "stg::ims_ab.load_hist" ADD CONSTRAINT PK_stg_ims_ab_load_hist PRIMARY KEY ("hist_id");



/* DDL FOR ims_ab.lookup_midas_crp_mnf */
CREATE TABLE "stg::ims_ab.lookup_midas_crp_mnf"(
  "maint_crp_mnf_lookup_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "crp" NVARCHAR(100) NOT NULL,
  "mnf" NVARCHAR(100) NOT NULL,
  "crp_mnf_midas" NVARCHAR(203) NULL
);

ALTER TABLE "stg::ims_ab.lookup_midas_crp_mnf" ADD CONSTRAINT PK_stg_ims_ab_lookup_midas_crp_mnf PRIMARY KEY ("maint_crp_mnf_lookup_id");



/* DDL FOR ims_ab.maint_dataview_rx_aggregated_crp_mnf */
CREATE TABLE "stg::ims_ab.maint_dataview_rx_aggregated_crp_mnf"(
  "maint_crp_mnf_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "cty" NVARCHAR(100) NULL,
  "crp" NVARCHAR(100) NULL,
  "mnf" NVARCHAR(100) NULL,
  "rx" DECIMAL(24,6) NULL,
  "crp_midas" NVARCHAR(100) NULL,
  "mnf_midas" NVARCHAR(100) NULL,
  "crp_mnf_midas" NVARCHAR(203) NULL,
  "maint_crp_mnf_lookup_id" INT NULL,
  "crp_mnf_midas_comment" NVARCHAR(4000) NULL,
  "crp_mnf_midas_changed_at" TIMESTAMP NULL,
  "crp_mnf_midas_changed_by" NVARCHAR(150) NULL,
  "crp_mnf_midas_condition" NVARCHAR(4000) NULL
);

ALTER TABLE "stg::ims_ab.maint_dataview_rx_aggregated_crp_mnf" ADD CONSTRAINT PK_stg_ims_ab_maint_dataview_rx_aggregated_crp_mnf PRIMARY KEY ("maint_crp_mnf_id");



/* DDL FOR ims_ab.maint_diag */
CREATE TABLE "stg::ims_ab.maint_diag"(
  "diag4_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "diag4" NVARCHAR(100) NULL,
  "diag4_code" NVARCHAR(4) NULL,
  "ab_indications" NVARCHAR(100) NULL,
  "ab_segments" NVARCHAR(100) NULL,
  "comment" NVARCHAR(100) NULL,
  "diag3_code" NVARCHAR(10) NULL,
  "diag3" NVARCHAR(100) NULL
);

ALTER TABLE "stg::ims_ab.maint_diag" ADD CONSTRAINT PK_stg_ims_ab_maint_diag PRIMARY KEY ("diag4_id");



/* DDL FOR ims_ab.mol */
CREATE TABLE "stg::ims_ab.mol"(
  "mol_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "mol" NVARCHAR(100) NULL,
  "mol_crp" NVARCHAR(100) NULL,
  "mol_cty" NVARCHAR(100) NULL,
  "mol_ldate" NVARCHAR(100) NULL
);

ALTER TABLE "stg::ims_ab.mol" ADD CONSTRAINT PK_stg_ims_ab_mol PRIMARY KEY ("mol_id");



/* DDL FOR ims_ab.mol_list */
CREATE TABLE "stg::ims_ab.mol_list"(
  "mol_list_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "mol_list" NVARCHAR(4000) NULL
);

ALTER TABLE "stg::ims_ab.mol_list" ADD CONSTRAINT PK_stg_ims_ab_mol_list PRIMARY KEY ("mol_list_id");



/* DDL FOR ims_ab.pack */
CREATE TABLE "stg::ims_ab.pack"(
  "source_code" NVARCHAR(5) NOT NULL,
  "source_id" NVARCHAR(10) NOT NULL,
  "pack_id" BIGINT NOT NULL,
  "gers_pack_id" BIGINT NOT NULL DEFAULT -1,
  "firom_pack_id" BIGINT NOT NULL DEFAULT -1,
  "cty" NVARCHAR(100) NOT NULL,
  "mkt_type" NVARCHAR(100) NOT NULL,
  "crp" NVARCHAR(100) NOT NULL,
  "mnf" NVARCHAR(100) NOT NULL,
  "mnf_own" INT NOT NULL,
  "atc1" NVARCHAR(1) NULL,
  "atc1_descr" NVARCHAR(100) NULL,
  "atc2" NVARCHAR(3) NULL,
  "atc2_descr" NVARCHAR(100) NULL,
  "atc3" NVARCHAR(4) NULL,
  "atc3_descr" NVARCHAR(100) NULL,
  "atc4" NVARCHAR(5) NULL,
  "atc4_descr" NVARCHAR(100) NOT NULL,
  "intprd" NVARCHAR(100) NOT NULL,
  "intprd_cty" NVARCHAR(100) NOT NULL,
  "intprd_ldate" NVARCHAR(7) NOT NULL,
  "prd" NVARCHAR(100) NOT NULL,
  "prd_mnf" NVARCHAR(100) NOT NULL,
  "prd_ldate" NVARCHAR(7) NOT NULL,
  "intrx" NVARCHAR(100) NOT NULL,
  "intreim" NVARCHAR(100) NOT NULL,
  "loreim" NVARCHAR(100) NOT NULL,
  "nfc1" NVARCHAR(1) NULL,
  "nfc1_descr" NVARCHAR(100) NULL,
  "nfc2" NVARCHAR(1) NULL,
  "nfc2_descr" NVARCHAR(100) NULL,
  "nfc12" NVARCHAR(2) NULL,
  "nfc12_descr" NVARCHAR(100) NULL,
  "nfc23" NVARCHAR(2) NULL,
  "nfc23_descr" NVARCHAR(100) NULL,
  "nfc123" NVARCHAR(3) NULL,
  "nfc123_descr" NVARCHAR(100) NOT NULL,
  "str" NVARCHAR(100) NOT NULL,
  "pres" NVARCHAR(100) NULL,
  "intstr" NVARCHAR(100) NOT NULL,
  "intsize" NVARCHAR(100) NULL,
  "intvol" NVARCHAR(100) NULL,
  "intpck" NVARCHAR(100) NOT NULL,
  "pck" NVARCHAR(100) NOT NULL,
  "pck_ldate" NVARCHAR(7) NOT NULL,
  "mol_list" NVARCHAR(4000) NULL,
  "dc0" INT NOT NULL,
  "data_source_id" INT NOT NULL,
  "sub_id" INT NULL,
  "crp_orig" NVARCHAR(100) NULL,
  "intprd_orig" NVARCHAR(100) NULL,
  "nprd" NVARCHAR(150) NULL,
  "mol_count" INT NULL,
  "mol_mono_combi" NVARCHAR(10) NULL,
  "subsegment" NVARCHAR(100) NULL,
  "rxotc_id" INT NULL,
  "rxotc" NVARCHAR(100) NULL,
  "country" NVARCHAR(100) NULL,
  "direct_reporting_country" NVARCHAR(29) NOT NULL,
  "country_group" NVARCHAR(100) NULL,
  "subregion" NVARCHAR(100) NULL,
  "region" NVARCHAR(100) NULL,
  "default_panel" NVARCHAR(18) NOT NULL,
  "flag_wh" INT NULL DEFAULT 0,
  "business_unit" NVARCHAR(100) NOT NULL DEFAULT '*not assigned*',
  "sbe" NVARCHAR(100) NOT NULL DEFAULT '*not assigned*',
  "segment" NVARCHAR(100) NOT NULL DEFAULT '*not assigned*',
  "responsible_business_unit" NVARCHAR(100) NOT NULL DEFAULT 'N.N.',
  "responsible_sbe" NVARCHAR(100) NOT NULL DEFAULT 'N.N.',
  "responsible_segment" NVARCHAR(100) NOT NULL DEFAULT 'N.N.',
  "responsible_subsegment" NVARCHAR(100) NOT NULL DEFAULT 'N.N.',
  "country_short_name" NVARCHAR(30) NOT NULL DEFAULT '*UNK*',
  "country_group_short_name" NVARCHAR(30) NOT NULL DEFAULT '*UNK*',
  "subregion_short_name" NVARCHAR(30) NOT NULL DEFAULT '*UNK*',
  "region_short_name" NVARCHAR(30) NOT NULL DEFAULT '*UNK*',
  "country_order_orig" INT NOT NULL DEFAULT 0,
  "country_group_order_orig" INT NOT NULL DEFAULT 0,
  "subregion_order_orig" INT NOT NULL DEFAULT 0,
  "region_order_orig" INT NOT NULL DEFAULT 0,
  "country_order" BIGINT NOT NULL DEFAULT 0,
  "country_group_order" BIGINT NOT NULL DEFAULT 0,
  "subregion_order" BIGINT NOT NULL DEFAULT 0,
  "region_order" BIGINT NOT NULL DEFAULT 0,
  "cty_2" NVARCHAR(100) NULL,
  "sub_id_orig" INT NULL,
  "subsegment_orig" NVARCHAR(100) NULL,
  "current_all_mol_list_id_orig" INT NULL,
  "mol_list_id_orig" INT NULL,
  "mol_list_orig" NVARCHAR(1000) NULL,
  "mol_list_maintained" NVARCHAR(1000) NULL,
  "mol_list_comment" NVARCHAR(4000) NULL,
  "mol_list_changed_at" TIMESTAMP NULL,
  "mol_list_changed_by" NVARCHAR(150) NULL,
  "mol_list_condition" NVARCHAR(4000) NULL,
  "intprd_corrected" NVARCHAR(100) NULL,
  "su_factor" DECIMAL(24,6) NULL,
  "prd_country_ldate" NVARCHAR(7) NULL,
  "prd_country_group_ldate" NVARCHAR(7) NULL,
  "prd_subregion_ldate" NVARCHAR(7) NULL,
  "prd_region_ldate" NVARCHAR(7) NULL,
  "prd_world_ldate" NVARCHAR(7) NULL,
  "prd_ldate_ims" NVARCHAR(7) NULL,
  "source_descr" NVARCHAR(100) NULL,
  "sex" NVARCHAR(50) NULL,
  "age" NVARCHAR(40) NULL,
  "panel_type_1" NVARCHAR(100) NULL DEFAULT 'COMBINED',
  "flag_mh" INT NULL DEFAULT 0,
  "age_sort_order" INT NULL DEFAULT 0,
  "atc4_corrected" NVARCHAR(5) NULL,
  "country_detailed_cd" NVARCHAR(300) NULL,
  "panel_type_2" NVARCHAR(100) NULL,
  "default_panel_current_all" NVARCHAR(18) NULL,
  "country_panel_cp" NVARCHAR(300) NULL,
  "product_group" NVARCHAR(100) NULL,
  "responsible_product_group" NVARCHAR(100) NULL,
  "product_group_orig" NVARCHAR(100) NULL,
  "ab_applications" NVARCHAR(100) NULL DEFAULT '*not assigned*',
  "default_panel_ab" NVARCHAR(18) NULL DEFAULT N'*not assigned*'
);

ALTER TABLE "stg::ims_ab.pack" ADD CONSTRAINT PK_stg_ims_ab_pack PRIMARY KEY ("pack_id");



