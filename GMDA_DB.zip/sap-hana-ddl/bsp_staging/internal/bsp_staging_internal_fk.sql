/* DDL FOR internal.maint_Country */
ALTER TABLE "stg::internal.maint_country" ADD CONSTRAINT "FK_stg_internal_maint_country_maint_country_country_lookup_id" FOREIGN KEY ("country_lookup_id") REFERENCES "stg::internal.maint_country_lookup"("country_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR internal.maint_IntProd */
ALTER TABLE "stg::internal.maint_intprod" ADD CONSTRAINT "FK_stg_internal_maint_intprod_maint_intprod_intprod_lookup_id" FOREIGN KEY ("intprod_lookup_id") REFERENCES "stg::internal.maint_intprod_lookup"("intprod_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::internal.maint_intprod" ADD CONSTRAINT "FK_stg_internal_maint_intprod_maint_intprod_product_group_lookup_id" FOREIGN KEY ("product_group_lookup_id") REFERENCES "stg::internal.maint_product_group_lookup"("product_group_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::internal.maint_intprod" ADD CONSTRAINT "FK_stg_internal_maint_intprod_maint_intprod_subsegment_lookup_id" FOREIGN KEY ("subsegment_lookup_id") REFERENCES "stg::internal.maint_subsegment_lookup"("subsegment_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;