/* DDL FOR monthlysales.AllFlat */
CREATE TABLE "stg::monthly_sales.all_flat"(
  "source_id" INT NULL,
  "period_id" INT NULL,
  "period" NVARCHAR(100) NULL,
  "cty" NVARCHAR(100) NULL,
  "crp" NVARCHAR(100) NULL DEFAULT N'*not available*',
  "mnf" NVARCHAR(100) NULL DEFAULT N'*not available*',
  "mnf_own" NVARCHAR(100) NULL DEFAULT N'*not available*',
  "atc3" NVARCHAR(100) NULL DEFAULT N'*not available*',
  "atc4" NVARCHAR(100) NULL,
  "intprd" NVARCHAR(100) NULL,
  "intprd_cty" NVARCHAR(100) NULL,
  "intprd_ldate" NVARCHAR(13) NULL,
  "prd" NVARCHAR(100) NULL,
  "prd_mnf" NVARCHAR(100) NULL,
  "prd_ldate" NVARCHAR(13) NULL,
  "nfc123" NVARCHAR(100) NULL DEFAULT N'*not available*',
  "str" NVARCHAR(100) NULL DEFAULT N'*not available*',
  "pck" NVARCHAR(100) NULL DEFAULT N'*not available*',
  "pck_ldate" NVARCHAR(15) NULL DEFAULT N'*not available*',
  "comp" NVARCHAR(100) NULL DEFAULT N'*not available*',
  "mol" NVARCHAR(100) NULL DEFAULT N'*not available*',
  "mol_cty" NVARCHAR(100) NULL DEFAULT N'*not available*',
  "mol_crp" NVARCHAR(100) NULL DEFAULT N'*not available*',
  "mol_ldate" NVARCHAR(15) NULL DEFAULT N'*not available*',
  "dc0" INT NULL,
  "un" DECIMAL(24,6) NULL,
  "cu" DECIMAL(24,6) NULL,
  "su" DECIMAL(24,6) NULL,
  "eur_mnf" DECIMAL(24,6) NULL,
  "eur_mnf_lp" NVARCHAR(20) NULL DEFAULT N'*not available*',
  "leu_mnf" DECIMAL(24,6) NULL,
  "leu_mnf_lp" NVARCHAR(20) NULL DEFAULT N'*not available*',
  "gen_prd" NVARCHAR(255) NULL DEFAULT N'*not available*',
  "prot_ection" NVARCHAR(255) NULL DEFAULT N'*not available*',
  "name_type" NVARCHAR(255) NULL DEFAULT N'*not available*',
  "intstr" NVARCHAR(255) NULL DEFAULT N'*not available*',
  "grp1" NVARCHAR(255) NULL DEFAULT N'*not available*',
  "grp2" NVARCHAR(255) NULL DEFAULT N'*not available*',
  "sec" NVARCHAR(255) NULL DEFAULT N'*not available*',
  "vendor" NVARCHAR(50) NOT NULL DEFAULT N'IQVIA',
  "intpck" NVARCHAR(100) NULL DEFAULT N'*not available*',
  "intbrd" NVARCHAR(100) NULL DEFAULT N'*not available*'
);



/* DDL FOR monthlysales.exchange_rates */
CREATE TABLE "stg::monthly_sales.exchange_rates"(
  "currency_code" NVARCHAR(5) NULL,
  "period" NVARCHAR(7) NULL,
  "rate" DECIMAL(24,6) NULL
);



/* DDL FOR monthlysales.exchange_rates_cty */
CREATE TABLE "stg::monthly_sales.exchange_rates_cty"(
  "currency_code" NVARCHAR(5) NULL,
  "panel_code" NVARCHAR(3) NULL,
  "country_code" NVARCHAR(3) NULL,
  "country_descr" NVARCHAR(50) NULL,
  "currency_descr" NVARCHAR(50) NULL,
  "ims_name" NVARCHAR(50) NULL
);



/* DDL FOR monthlysales.fact_exrate_eur_to_target */
CREATE TABLE "stg::monthly_sales.fact_exrate_eur_to_target"(
  "target_currency_id" SMALLINT NULL,
  "iso_currency_code" NVARCHAR(3) NOT NULL,
  "month_id" INT NULL,
  "rate" DECIMAL(24,6) NULL
);



/* DDL FOR monthlysales.fact_exrate_panel_to_eur */
CREATE TABLE "stg::monthly_sales.fact_exrate_panel_to_eur"(
  "month_id" INT NULL,
  "panel" NVARCHAR(255) NULL,
  "exrate" DECIMAL(24,6) NULL
);



/* DDL FOR monthlysales.FlatFileFact_S1P */
CREATE TABLE "stg::monthly_sales.flat_file_fact_s1p"(
  "dim_id" INT NULL,
  "yyyymm" INT NULL,
  "period_type" NVARCHAR(4) NULL,
  "usd_mnf" DECIMAL(24,6) NULL,
  "eur_mnf" DECIMAL(24,6) NULL,
  "lce_mnf" DECIMAL(24,6) NULL,
  "su" DECIMAL(24,6) NULL,
  "source_id" INT NULL
);



/* DDL FOR monthlysales.FlatFileFact_Xarelto */
CREATE TABLE "stg::monthly_sales.flat_file_fact_xarelto"(
  "dim_id" INT NULL,
  "yyyymm" INT NULL,
  "period_type" NVARCHAR(4) NULL,
  "usd_mnf" DECIMAL(24,6) NULL,
  "eur_mnf" DECIMAL(24,6) NULL,
  "lce_mnf" DECIMAL(24,6) NULL,
  "un" DECIMAL(24,6) NULL,
  "cu" DECIMAL(24,6) NULL,
  "su" DECIMAL(24,6) NULL,
  "usd_mnf_lp" DECIMAL(24,6) NULL,
  "eur_mnf_lp" DECIMAL(24,6) NULL,
  "lce_mnf_lp" DECIMAL(24,6) NULL,
  "source_id" INT NULL
);



/* DDL FOR monthlysales.FlatFileFact_Xarelto_CAD */
CREATE TABLE "stg::monthly_sales.flat_file_fact_xarelto_cad"(
  "dim_id" INT NULL,
  "yyyymm" INT NULL,
  "period_type" NVARCHAR(4) NULL,
  "usd_mnf" DECIMAL(24,6) NULL,
  "eur_mnf" DECIMAL(24,6) NULL,
  "lce_mnf" DECIMAL(24,6) NULL,
  "un" DECIMAL(24,6) NULL,
  "cu" DECIMAL(24,6) NULL,
  "su" DECIMAL(24,6) NULL,
  "source_id" INT NULL
);



/* DDL FOR monthlysales.FlatFileLookup_S1P */
CREATE TABLE "stg::monthly_sales.flat_file_lookup_s1p"(
  "dim_id" INT NULL,
  "cty" NVARCHAR(3) NULL,
  "cty_descr" NVARCHAR(21) NULL,
  "atc4" NVARCHAR(4) NULL,
  "intprd" NVARCHAR(8) NULL,
  "intprd_cty" NVARCHAR(3) NULL,
  "intprd_ldate" NVARCHAR(6) NULL,
  "prd" NVARCHAR(18) NULL,
  "prd_ldate" NVARCHAR(6) NULL,
  "prd_mnf" NVARCHAR(3) NULL,
  "dc1" NVARCHAR(9) NULL,
  "sec" NVARCHAR(8) NULL,
  "cty_grp1" NVARCHAR(13) NULL,
  "cty_grp2" NVARCHAR(12) NULL,
  "source_id" INT NULL,
  "pck" NVARCHAR(30) NULL,
  "pck_ldate" NVARCHAR(30) NULL,
  "nfc123" NVARCHAR(18) NULL,
  "intbrd" NVARCHAR(30) NULL
);



/* DDL FOR monthlysales.FlatFileLookup_Xarelto */
CREATE TABLE "stg::monthly_sales.flat_file_lookup_xarelto"(
  "dim_id" INT NULL,
  "cty" NVARCHAR(3) NULL,
  "cty_descr" NVARCHAR(20) NULL,
  "crp" NVARCHAR(18) NULL,
  "mnf" NVARCHAR(18) NULL,
  "mnf_own" NVARCHAR(2) NULL,
  "atc4" NVARCHAR(4) NULL,
  "intprd" NVARCHAR(18) NULL,
  "intprd_cty" NVARCHAR(3) NULL,
  "intprd_ldate" NVARCHAR(6) NULL,
  "prd" NVARCHAR(18) NULL,
  "prd_ldate" NVARCHAR(6) NULL,
  "prd_mnf" NVARCHAR(3) NULL,
  "nfc123" NVARCHAR(3) NULL,
  "pck" NVARCHAR(31) NULL,
  "pck_ldate" NVARCHAR(6) NULL,
  "mol" NVARCHAR(27) NULL,
  "mol_cty" NVARCHAR(3) NULL,
  "mol_ldate" NVARCHAR(6) NULL,
  "mol_crp" NVARCHAR(18) NULL,
  "mol_list" NVARCHAR(27) NULL,
  "mol_count" NVARCHAR(1) NULL,
  "dc1" NVARCHAR(9) NULL,
  "source_id" INT NULL,
  "intstr" NVARCHAR(50) NULL,
  "intpck" NVARCHAR(100) NULL,
  "comp" NVARCHAR(100) NULL,
  "intbrd" NVARCHAR(20) NULL
);



/* DDL FOR monthlysales.FlatFileLookup_Xarelto_CAD */
CREATE TABLE "stg::monthly_sales.flat_file_lookup_xarelto_cad"(
  "dim_id" INT NULL,
  "cty" NVARCHAR(3) NULL,
  "cty_descr" NVARCHAR(20) NULL,
  "crp" NVARCHAR(18) NULL,
  "mnf" NVARCHAR(18) NULL,
  "mnf_own" NVARCHAR(2) NULL,
  "atc4" NVARCHAR(4) NULL,
  "intprd" NVARCHAR(18) NULL,
  "intprd_cty" NVARCHAR(3) NULL,
  "intprd_ldate" NVARCHAR(6) NULL,
  "prd" NVARCHAR(18) NULL,
  "prd_ldate" NVARCHAR(6) NULL,
  "prd_mnf" NVARCHAR(3) NULL,
  "nfc123" NVARCHAR(3) NULL,
  "pck" NVARCHAR(31) NULL,
  "pck_ldate" NVARCHAR(6) NULL,
  "mol" NVARCHAR(27) NULL,
  "mol_cty" NVARCHAR(3) NULL,
  "mol_ldate" NVARCHAR(6) NULL,
  "mol_crp" NVARCHAR(18) NULL,
  "mol_list" NVARCHAR(27) NULL,
  "mol_count" NVARCHAR(1) NULL,
  "dc1" NVARCHAR(9) NULL,
  "source_id" INT NULL,
  "intstr" NVARCHAR(50) NULL,
  "intpck" NVARCHAR(100) NULL,
  "comp" NVARCHAR(100) NULL,
  "intbrd" NVARCHAR(20) NULL
);



/* DDL FOR monthlysales.gers_monthly_data */
CREATE TABLE "stg::monthly_sales.gers_monthly_data"(
  "pack_id" BIGINT NOT NULL,
  "month_yyyymm" INT NOT NULL,
  "cty" NVARCHAR(50) NOT NULL,
  "country" NVARCHAR(20) NOT NULL,
  "corporation" NVARCHAR(100) NULL,
  "manufacturer" NVARCHAR(16) NULL,
  "atc4" NVARCHAR(100) NULL,
  "nfc123" NVARCHAR(100) NULL,
  "intprd" NVARCHAR(100) NULL,
  "intprd_ldate_yyyymm" INT NULL,
  "product" NVARCHAR(32) NULL,
  "prd_ldate_yyymm" INT NULL,
  "pack" NVARCHAR(64) NULL,
  "launch_date" INT NULL,
  "strength" NVARCHAR(15) NULL,
  "mol" NVARCHAR(100) NULL,
  "dc0" INT NULL,
  "mol_list" NVARCHAR(4000) NULL,
  "su_factor" DECIMAL(24,6) NULL,
  "product_group" NVARCHAR(100) NOT NULL,
  "source_id" INT NOT NULL,
  "sales" BIGINT NULL,
  "units" BIGINT NULL,
  "su" BIGINT NULL
);



/* DDL FOR monthlysales.ih_monthly_data */
CREATE TABLE "stg::monthly_sales.ih_monthly_data"(
  "pack_id" BIGINT NOT NULL,
  "month_yyyymm" INT NOT NULL,
  "cty" NVARCHAR(50) NOT NULL,
  "country" NVARCHAR(20) NOT NULL,
  "corporation" NVARCHAR(100) NULL,
  "manufacturer" NVARCHAR(16) NULL,
  "atc4" NVARCHAR(100) NULL,
  "nfc123" NVARCHAR(100) NULL,
  "intprd" NVARCHAR(100) NULL,
  "intprd_ldate_yyyymm" INT NULL,
  "product" NVARCHAR(32) NULL,
  "prd_ldate_yyymm" INT NULL,
  "pack" NVARCHAR(64) NULL,
  "launch_date" INT NULL,
  "strength" NVARCHAR(15) NULL,
  "mol" NVARCHAR(100) NULL,
  "dc0" INT NULL,
  "mol_list" NVARCHAR(4000) NULL,
  "su_factor" DECIMAL(24,6) NULL,
  "product_group" NVARCHAR(100) NOT NULL,
  "source_id" INT NOT NULL,
  "sales" BIGINT NULL,
  "units" BIGINT NULL,
  "su" BIGINT NULL
);



/* DDL FOR monthlysales.IMSCountryMapping */
CREATE TABLE "stg::monthly_sales.ims_country_mapping"(
  "country_desc_flat_file" NVARCHAR(50) NOT NULL,
  "country_desc_data_view" NVARCHAR(50) NULL
);

/* DDL FOR monthlysales.meta_data */
CREATE TABLE "stg::monthly_sales.meta_data"(
  "market" NVARCHAR(50) NOT NULL,
  "product_group" NVARCHAR(100) NOT NULL,
  "source_id" INT NOT NULL,
  "use_non_ims_data" TINYINT NOT NULL DEFAULT 0,
  "source_code" NVARCHAR(20) NOT NULL
);

/* DDL FOR monthly_sales.raw_flat_file_xarelto" */
CREATE TABLE "stg::monthly_sales.raw_flat_file_xarelto"(
  "dim_id" INTEGER NULL,
  "cty" NVARCHAR(3) NULL,
  "cty_descr" NVARCHAR(20) NULL,
  "crp" NVARCHAR(18) NULL,
  "mnf" NVARCHAR(18) NULL,
  "mnf_own" NVARCHAR(2) NULL,
  "atc4" NVARCHAR(4) NULL,
  "intprd" NVARCHAR(18) NULL,
  "intprd_cty" NVARCHAR(3) NULL,
  "intprd_ldate" NVARCHAR(6) NULL,
  "prd" NVARCHAR(18) NULL,
  "prd_ldate" NVARCHAR(6) NULL,
  "prd_mnf" NVARCHAR(3) NULL,
  "intstr" NVARCHAR(50) NULL,
  "nfc123" NVARCHAR(3) NULL,
  "intpck" NVARCHAR(100) NULL,
  "pck" NVARCHAR(31) NULL,
  "comp" NVARCHAR(100) NULL,
  "pck_ldate" NVARCHAR(6) NULL,
  "mol" NVARCHAR(100) NULL,
  "mol_cty" NVARCHAR(3) NULL,
  "mol_ldate" NVARCHAR(6) NULL,
  "mol_crp" NVARCHAR(18) NULL,
  "mol_list" NVARCHAR(100) NULL,
  "mol_count" NVARCHAR(1) NULL,
  "dc1" NVARCHAR(9) NULL,
  "intbrand" NVARCHAR(100) NULL,
  "period_type" NVARCHAR(4) NULL,
  "yyyymm" INTEGER NULL,
  "usd_mnf"  DECIMAL(24,6) NULL,
  "eur_mnf"  DECIMAL(24,6) NULL,
  "lce_mnf"  DECIMAL(24,6) NULL,
  "un"  DECIMAL(24,6) NULL,
  "cu"  DECIMAL(24,6) NULL,
  "su"  DECIMAL(24,6) NULL,
  "usd_mnf_lp"  DECIMAL(24,6) NULL,
  "eur_mnf_lp"  DECIMAL(24,6) NULL,
  "lce_mnf_lp"  DECIMAL(24,6) NULL
);

/* DDL FOR monthly_sales.raw_flat_file_xarelto_cad" */
CREATE TABLE "stg::monthly_sales.raw_flat_file_xarelto_cad"(
	"dim_id" INTEGER NULL,
	"cty" NVARCHAR(3) NULL,
	"cty_descr" NVARCHAR(20) NULL,
	"crp" NVARCHAR(18) NULL,
	"mnf" NVARCHAR(18) NULL,
	"mnf_own" NVARCHAR(2) NULL,
	"atc3" NVARCHAR(4) NULL,
	"atc3_descr" NVARCHAR(100) NULL,
	"atc4" NVARCHAR(4) NULL,
	"atc4_descr" NVARCHAR(100) NULL,
	"intprd" NVARCHAR(18) NULL,
	"intprd_cty" NVARCHAR(3) NULL,
	"intprd_ldate" NVARCHAR(6) NULL,
	"prd" NVARCHAR(18) NULL,
	"prd_ldate" NVARCHAR(6) NULL,
	"prd_mnf" NVARCHAR(3) NULL,
	"intstr" NVARCHAR(50) NULL,
	"nfc123" NVARCHAR(3) NULL,
	"nfc123_descr" NVARCHAR(100) NULL,
	"intpck" NVARCHAR(100) NULL,
	"pck" NVARCHAR(31) NULL,
	"pck_ldate" NVARCHAR(6) NULL,
	"comp" NVARCHAR(100) NULL,
	"mol" NVARCHAR(100) NULL,
	"mol_cty" NVARCHAR(3) NULL,
	"mol_ldate" NVARCHAR(6) NULL,
	"mol_crp" NVARCHAR(18) NULL,
	"mol_list" NVARCHAR(100) NULL,
	"mol_count" NVARCHAR(1) NULL,
	"dc1" NVARCHAR(9) NULL,
	"intbrd" NVARCHAR(100) NULL,
	"period_type" NVARCHAR(4) NULL,
	"yyyymm" INTEGER NULL,
	"usd_mnf"  DECIMAL(24,6) NULL,
	"eur_mnf"  DECIMAL(24,6) NULL,
	"lce_mnf"  DECIMAL(24,6) NULL,
	"un"  DECIMAL(24,6) NULL,
	"cu"  DECIMAL(24,6) NULL,
	"su"  DECIMAL(24,6) NULL
);

/* DDL FOR monthly_sales.raw_flat_file_xarelto_s1p" */
CREATE TABLE "stg::monthly_sales.raw_flat_file_xarelto_s1p" (
	"dim_id" INTEGER NULL,
	"dc1" NVARCHAR(9) NULL,
	"cty" NVARCHAR(3) NULL,
	"cty_descr" NVARCHAR(21) NULL,
	"sec" NVARCHAR(8) NULL,
	"atc4" NVARCHAR(4) NULL,
	"intprd" NVARCHAR(8) NULL,
	"intprd_cty" NVARCHAR(3) NULL,
	"intprd_ldate" NVARCHAR(6) NULL,
	"prd" NVARCHAR(18) NULL,
	"prd_ldate" NVARCHAR(6) NULL,
	"prd_mnf" NVARCHAR(3) NULL,
	"pck" NVARCHAR(30) NULL,
	"pck_ldate" NVARCHAR(30) NULL,
	"nfc123" NVARCHAR(18) NULL,
	"intbrd" NVARCHAR(30) NULL,
	"cty_grp1" NVARCHAR(13) NULL,
	"cty_grp2" NVARCHAR(12) NULL,
	"period_type" NVARCHAR(4) NULL,
	"yyyymm" INTEGER NULL,
	"usd_mnf"  DECIMAL(24,6) NULL,
	"eur_mnf"  DECIMAL(24,6) NULL,
	"lce_mnf"  DECIMAL(24,6) NULL,
	"su"  DECIMAL(24,6)  NULL
);