/* DDL FOR ims_midas_qtr.bridge_mol_list_to_mol */
ALTER TABLE "stg::ims_midas_qtr.bridge_mol_list_to_mol" ADD CONSTRAINT "FK_stg_ims_midas_qtr_bridge_mol_list_to_mol_bridge_mol_list_to_mol_mol_id" FOREIGN KEY ("mol_id") REFERENCES "stg::ims_midas_qtr.dim_mol"("mol_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::ims_midas_qtr.bridge_mol_list_to_mol" ADD CONSTRAINT "FK_stg_ims_midas_qtr_bridge_mol_list_to_mol_bridge_mol_list_to_mol_mol_list_id" FOREIGN KEY ("mol_list_id") REFERENCES "stg::ims_midas_qtr.dim_mol_list"("mol_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ims_midas_qtr.dim_cty */
ALTER TABLE "stg::ims_midas_qtr.dim_cty" ADD CONSTRAINT "FK_stg_ims_midas_qtr_dim_cty_dim_cty_cty_sel_id" FOREIGN KEY ("cty_sel_id") REFERENCES "stg::di.dim_midas_sel_cty"("cty_sel_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ims_midas_qtr.Load_IMS_Midas_QTR_flatfile_DIM_hist */
ALTER TABLE "stg::ims_midas_qtr.load_ims_midas_qtr_flatfile_dim_hist" ADD CONSTRAINT "FK_stg_ims_midas_qtr_load_ims_midas_qtr_flatfile_dim_hist_load_ims_midas_qtr_flatfile_dim_hist_hist_id" FOREIGN KEY ("hist_id") REFERENCES "stg::ims_midas_qtr.load_ims_midas_qtr_flatfile_hist"("hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ims_midas_qtr.Load_IMS_Midas_QTR_flatfile_FACTS_hist */
ALTER TABLE "stg::ims_midas_qtr.load_ims_midas_qtr_flatfile_facts_hist" ADD CONSTRAINT "FK_stg_ims_midas_qtr_load_ims_midas_qtr_flatfile_facts_hist_load_ims_midas_qtr_flatfile_facts_hist_hist_id" FOREIGN KEY ("hist_id") REFERENCES "stg::ims_midas_qtr.load_ims_midas_qtr_flatfile_hist"("hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;