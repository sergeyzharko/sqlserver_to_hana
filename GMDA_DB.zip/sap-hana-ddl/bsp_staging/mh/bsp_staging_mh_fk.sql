/* DDL FOR mh.dim_pack */
ALTER TABLE "stg::mh.dim_pack" ADD CONSTRAINT "FK_stg_mh_dim_pack_dim_pack_maint_patient_month_factor_lookup_id" FOREIGN KEY ("maint_patient_month_factor_lookup_id") REFERENCES "stg::mh.maint_patient_month_factor_lookup"("maint_patient_month_factor_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR mh.dim_pack_bck */
ALTER TABLE "stg::mh.dim_pack_bck" ADD CONSTRAINT "FK_stg_mh_dim_pack_bck_dim_pack_bck_maint_patient_month_factor_lookup_id" FOREIGN KEY ("maint_patient_month_factor_lookup_id") REFERENCES "stg::mh.maint_patient_month_factor_lookup"("maint_patient_month_factor_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR mh.dim_pack_bck_wo_dc0 */
ALTER TABLE "stg::mh.dim_pack_bck_wo_dc0" ADD CONSTRAINT "FK_stg_mh_dim_pack_bck_wo_dc0_dim_pack_bck_wo_dc0_maint_patient_month_factor_lookup_id" FOREIGN KEY ("maint_patient_month_factor_lookup_id") REFERENCES "stg::mh.maint_patient_month_factor_lookup"("maint_patient_month_factor_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR mh.dim_pack_wo_dc0 */
ALTER TABLE "stg::mh.dim_pack_wo_dc0" ADD CONSTRAINT "FK_stg_mh_dim_pack_wo_dc0_dim_pack_wo_dc0_maint_patient_month_factor_lookup_id" FOREIGN KEY ("maint_patient_month_factor_lookup_id") REFERENCES "stg::mh.maint_patient_month_factor_lookup"("maint_patient_month_factor_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;