/* DDL FOR di.bridge_mol_list_to_mol */
ALTER TABLE "stg::di.bridge_mol_list_to_mol" ADD CONSTRAINT "FK_stg_di_bridge_mol_list_to_mol_bridge_mol_list_to_mol_mol_id" FOREIGN KEY ("mol_id") REFERENCES "stg::di.dim_mol"("mol_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::di.bridge_mol_list_to_mol" ADD CONSTRAINT "FK_stg_di_bridge_mol_list_to_mol_bridge_mol_list_to_mol_mol_list_id" FOREIGN KEY ("mol_list_id") REFERENCES "stg::di.dim_mol_list"("mol_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR di.DDD_src_hist */
ALTER TABLE "stg::di.ddd_src_hist" ADD CONSTRAINT "FK_stg_di_ddd_src_hist_ddd_src_hist_hist_id" FOREIGN KEY ("hist_id") REFERENCES "stg::di.ddd_log_hist"("hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR di.dim_cty */
ALTER TABLE "stg::di.dim_cty" ADD CONSTRAINT "FK_stg_di_dim_cty_dim_cty_cty_sel_id" FOREIGN KEY ("cty_sel_id") REFERENCES "stg::di.dim_midas_sel_cty"("cty_sel_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR di.ODS_AMR_country */
ALTER TABLE "stg::di.ods_amr_country" ADD CONSTRAINT "FK_stg_di_ods_amr_country_ods_amr_country_cty_id" FOREIGN KEY ("cty_id") REFERENCES "stg::di.ods_mapping_country"("cty_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR di.ODS_AMR_country_product_marketer */
ALTER TABLE "stg::di.ods_amr_country_product_marketer" ADD CONSTRAINT "FK_stg_di_ods_amr_country_product_marketer_ods_amr_country_product_marketer_map_id" FOREIGN KEY ("map_id") REFERENCES "stg::di.ods_mapping_glocon_uni"("map_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::di.ods_amr_country_product_marketer" ADD CONSTRAINT "FK_stg_di_ods_amr_country_product_marketer_ods_amr_country_product_marketer_sub_id" FOREIGN KEY ("sub_id") REFERENCES "stg::di.ods_subsegment"("sub_id") ON DELETE RESTRICT ON UPDATE RESTRICT;