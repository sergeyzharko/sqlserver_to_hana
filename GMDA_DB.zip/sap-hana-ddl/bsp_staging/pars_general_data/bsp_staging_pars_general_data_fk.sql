/* DDL FOR pars_general_data.commercial_operation */
ALTER TABLE "stg::pars_general_data.commercial_operation" ADD CONSTRAINT "FK_stg_pars_general_data_commercial_operation_commercial_operation_parent_id" FOREIGN KEY ("parent_id") REFERENCES "stg::pars_general_data.division"("object_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR pars_general_data.commercial_operation_hist */
ALTER TABLE "stg::pars_general_data.commercial_operation_hist" ADD CONSTRAINT "FK_stg_pars_general_data_commercial_operation_hist_commercial_operation_hist_parent_id_hist_id" FOREIGN KEY ("parent_id","hist_id") REFERENCES "stg::pars_general_data.division_hist"("object_id","hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR pars_general_data.country */
ALTER TABLE "stg::pars_general_data.country" ADD CONSTRAINT "FK_stg_pars_general_data_country_country_parent_id" FOREIGN KEY ("parent_id") REFERENCES "stg::pars_general_data.country_group"("object_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR pars_general_data.country_group */
ALTER TABLE "stg::pars_general_data.country_group" ADD CONSTRAINT "FK_stg_pars_general_data_country_group_country_group_parent_id" FOREIGN KEY ("parent_id") REFERENCES "stg::pars_general_data.subregion"("object_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR pars_general_data.country_group_hist */
ALTER TABLE "stg::pars_general_data.country_group_hist" ADD CONSTRAINT "FK_stg_pars_general_data_country_group_hist_country_group_hist_hist_id" FOREIGN KEY ("hist_id") REFERENCES "stg::pars_general_data.load_hist_reg_struct"("hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::pars_general_data.country_group_hist" ADD CONSTRAINT "FK_stg_pars_general_data_country_group_hist_country_group_hist_parent_id_hist_id" FOREIGN KEY ("parent_id","hist_id") REFERENCES "stg::pars_general_data.subregion_hist"("object_id","hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR pars_general_data.country_hist */
ALTER TABLE "stg::pars_general_data.country_hist" ADD CONSTRAINT "FK_stg_pars_general_data_country_hist_country_hist_parent_id_hist_id" FOREIGN KEY ("parent_id","hist_id") REFERENCES "stg::pars_general_data.country_group_hist"("object_id","hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::pars_general_data.country_hist" ADD CONSTRAINT "FK_stg_pars_general_data_country_hist_country_hist_hist_id" FOREIGN KEY ("hist_id") REFERENCES "stg::pars_general_data.load_hist_reg_struct"("hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR pars_general_data.division */
ALTER TABLE "stg::pars_general_data.division" ADD CONSTRAINT "FK_stg_pars_general_data_division_division_parent_id" FOREIGN KEY ("parent_id") REFERENCES "stg::pars_general_data.subgroup"("object_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR pars_general_data.division_hist */
ALTER TABLE "stg::pars_general_data.division_hist" ADD CONSTRAINT "FK_stg_pars_general_data_division_hist_division_hist_hist_id" FOREIGN KEY ("hist_id") REFERENCES "stg::pars_general_data.load_hist_reg_struct"("hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::pars_general_data.division_hist" ADD CONSTRAINT "FK_stg_pars_general_data_division_hist_division_hist_parent_id_hist_id" FOREIGN KEY ("parent_id","hist_id") REFERENCES "stg::pars_general_data.subgroup_hist"("object_id","hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR pars_general_data.load_reg_structure_short_name_order_hist */
ALTER TABLE "stg::pars_general_data.load_reg_structure_short_name_order_hist" ADD CONSTRAINT "FK_stg_pars_general_data_load_reg_structure_short_name_order_hist_load_reg_structure_short_name_order_hist_hist_id" FOREIGN KEY ("hist_id") REFERENCES "stg::pars_general_data.load_hist_reg_struct"("hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR pars_general_data.Midas_panel_local_currency */
ALTER TABLE "stg::pars_general_data.midas_panel_local_currency" ADD CONSTRAINT "FK_stg_pars_general_data_midas_panel_local_currency_midas_panel_local_currency_currency_iso" FOREIGN KEY ("currency_iso") REFERENCES "stg::pars_general_data.source_currency"("iso_currency_code") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR pars_general_data.region */
ALTER TABLE "stg::pars_general_data.region" ADD CONSTRAINT "FK_stg_pars_general_data_region_region_parent_id" FOREIGN KEY ("parent_id") REFERENCES "stg::pars_general_data.commercial_operation"("object_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR pars_general_data.region_hist */
ALTER TABLE "stg::pars_general_data.region_hist" ADD CONSTRAINT "FK_stg_pars_general_data_region_hist_region_hist_parent_id_hist_id" FOREIGN KEY ("parent_id","hist_id") REFERENCES "stg::pars_general_data.commercial_operation_hist"("object_id","hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::pars_general_data.region_hist" ADD CONSTRAINT "FK_stg_pars_general_data_region_hist_region_hist_hist_id" FOREIGN KEY ("hist_id") REFERENCES "stg::pars_general_data.load_hist_reg_struct"("hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR pars_general_data.subgroup_hist */
ALTER TABLE "stg::pars_general_data.subgroup_hist" ADD CONSTRAINT "FK_stg_pars_general_data_subgroup_hist_subgroup_hist_hist_id" FOREIGN KEY ("hist_id") REFERENCES "stg::pars_general_data.load_hist_reg_struct"("hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR pars_general_data.subregion */
ALTER TABLE "stg::pars_general_data.subregion" ADD CONSTRAINT "FK_stg_pars_general_data_subregion_subregion_parent_id" FOREIGN KEY ("parent_id") REFERENCES "stg::pars_general_data.region"("object_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR pars_general_data.subregion_hist */
ALTER TABLE "stg::pars_general_data.subregion_hist" ADD CONSTRAINT "FK_stg_pars_general_data_subregion_hist_subregion_hist_hist_id" FOREIGN KEY ("hist_id") REFERENCES "stg::pars_general_data.load_hist_reg_struct"("hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::pars_general_data.subregion_hist" ADD CONSTRAINT "FK_stg_pars_general_data_subregion_hist_subregion_hist_parent_id_hist_id" FOREIGN KEY ("parent_id","hist_id") REFERENCES "stg::pars_general_data.region_hist"("object_id","hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;