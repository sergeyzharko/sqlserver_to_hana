/* DDL FOR firom.maint_CRP_lookup */
ALTER TABLE "stg::firom.maint_crp_lookup" ADD CONSTRAINT "FK_stg_firom_maint_crp_lookup_maint_crp_lookup_maint_crp_list_id" FOREIGN KEY ("maint_crp_list_id") REFERENCES "stg::firom.maint_crp_list"("maint_crp_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR firom.maint_GenericName_lookup */
ALTER TABLE "stg::firom.maint_generic_name_lookup" ADD CONSTRAINT "FK_stg_firom_maint_generic_name_lookup_maint_generic_name_lookup_maint_mol_list_id" FOREIGN KEY ("maint_mol_list_id") REFERENCES "stg::firom.maint_mol_list"("maint_mol_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR firom.maint_MNF */
ALTER TABLE "stg::firom.maint_mnf" ADD CONSTRAINT "FK_stg_firom_maint_mnf_maint_mnf_maint_crp_list_id" FOREIGN KEY ("maint_crp_list_id") REFERENCES "stg::firom.maint_crp_list"("maint_crp_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR firom.maint_Mol_lookup */
ALTER TABLE "stg::firom.maint_mol_lookup" ADD CONSTRAINT "FK_stg_firom_maint_mol_lookup_maint_mol_lookup_maint_mol_list_id" FOREIGN KEY ("maint_mol_list_id") REFERENCES "stg::firom.maint_mol_list"("maint_mol_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR firom.maint_Name_lookup */
ALTER TABLE "stg::firom.maint_name_lookup" ADD CONSTRAINT "FK_stg_firom_maint_name_lookup_maint_name_lookup_maint_mol_list_id" FOREIGN KEY ("maint_mol_list_id") REFERENCES "stg::firom.maint_mol_list"("maint_mol_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR firom.maint_Pack */
ALTER TABLE "stg::firom.maint_pack" ADD CONSTRAINT "FK_stg_firom_maint_pack_maint_pack_maint_atc4_lookup_id" FOREIGN KEY ("maint_atc4_lookup_id") REFERENCES "stg::firom.maint_atc4_lookup"("maint_atc4_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::firom.maint_pack" ADD CONSTRAINT "FK_stg_firom_maint_pack_maint_pack_maint_intpck_lookup_id" FOREIGN KEY ("maint_intpck_lookup_id") REFERENCES "stg::firom.maint_intpck_lookup"("maint_intpck_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::firom.maint_pack" ADD CONSTRAINT "FK_stg_firom_maint_pack_maint_pack_maint_intprod_lookup_id" FOREIGN KEY ("maint_intprod_lookup_id") REFERENCES "stg::firom.maint_intprod_lookup"("maint_intprod_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::firom.maint_pack" ADD CONSTRAINT "FK_stg_firom_maint_pack_maint_pack_maint_intstr_lookup_id" FOREIGN KEY ("maint_intstr_lookup_id") REFERENCES "stg::firom.maint_intstr_lookup"("maint_intstr_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::firom.maint_pack" ADD CONSTRAINT "FK_stg_firom_maint_pack_maint_pack_maint_mol_list_id" FOREIGN KEY ("maint_mol_list_id") REFERENCES "stg::firom.maint_mol_list"("maint_mol_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::firom.maint_pack" ADD CONSTRAINT "FK_stg_firom_maint_pack_maint_pack_maint_nfc_lookup_id" FOREIGN KEY ("maint_nfc_lookup_id") REFERENCES "stg::firom.maint_nfc_lookup"("maint_nfc_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::firom.maint_pack" ADD CONSTRAINT "FK_stg_firom_maint_pack_maint_pack_maint_subsegment_lookup_id" FOREIGN KEY ("maint_subsegment_lookup_id") REFERENCES "stg::firom.maint_subsegment_lookup"("maint_subsegment_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;