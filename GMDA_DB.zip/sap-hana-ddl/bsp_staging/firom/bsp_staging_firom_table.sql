/* DDL FOR firom.load_Fact */
CREATE TABLE "stg::firom.load_fact"(
  "farm_inform_code" INT NOT NULL,
  "period_yyyymm" INT NOT NULL,
  "rule" NVARCHAR(25) NOT NULL,
  "sales_units" INT NULL
);

ALTER TABLE "stg::firom.load_fact" ADD CONSTRAINT PK_stg_firom_load_fact PRIMARY KEY ("farm_inform_code", "period_yyyymm", "rule");



/* DDL FOR firom.load_Fact_all_bckdata */
CREATE TABLE "stg::firom.load_fact_all_bckdata"(
  "farm_inform_code" INT NOT NULL,
  "period_yyyymm" INT NOT NULL,
  "rule" NVARCHAR(25) NOT NULL,
  "sales_units" INT NULL
);

ALTER TABLE "stg::firom.load_fact_all_bckdata" ADD CONSTRAINT PK_stg_firom_load_fact_all_bckdata PRIMARY KEY ("farm_inform_code", "period_yyyymm", "rule");



/* DDL FOR firom.load_Fact_hist */
CREATE TABLE "stg::firom.load_fact_hist"(
  "farm_inform_code" INT NOT NULL,
  "period_yyyymm" INT NOT NULL,
  "rule" NVARCHAR(25) NOT NULL,
  "hist_id" INT NOT NULL,
  "sales_units" INT NULL
);

ALTER TABLE "stg::firom.load_fact_hist" ADD CONSTRAINT PK_stg_firom_load_fact_hist PRIMARY KEY ("farm_inform_code", "period_yyyymm", "rule", "hist_id");



/* DDL FOR firom.load_Pack */
CREATE TABLE "stg::firom.load_pack"(
  "farm_inform_code" INT NOT NULL,
  "name" NVARCHAR(40) NULL,
  "subname" NVARCHAR(40) NULL,
  "description" NVARCHAR(50) NULL,
  "minicardcode" NVARCHAR(7) NULL,
  "launch_date_yyyymm" INT NULL,
  "atc_ephmra" NVARCHAR(8) NULL,
  "fotc" NVARCHAR(8) NULL,
  "ean" NVARCHAR(13) NULL,
  "ehibc" NVARCHAR(13) NULL,
  "knmp" NVARCHAR(8) NULL,
  "generic_name" NVARCHAR(50) NULL,
  "form" NVARCHAR(50) NULL,
  "strength_size" BIGINT NULL,
  "strength_unit" NVARCHAR(10) NULL,
  "pack_form" NVARCHAR(12) NULL,
  "pack_size" INT NULL,
  "pack_unit" NVARCHAR(5) NULL,
  "subpackage_size" INT NULL,
  "subpackage_unit" NVARCHAR(5) NULL,
  "farm_inform_participant" NVARCHAR(50) NULL,
  "purchase_channel" NVARCHAR(25) NULL,
  "country_of_origin" NVARCHAR(25) NULL,
  "atc_who" NVARCHAR(8) NULL,
  "ddds_per_pack" INT NULL,
  "registered" NVARCHAR(15) NULL,
  "ur_nr" NVARCHAR(2) NULL,
  "market_coverage" NVARCHAR(50) NULL
);

ALTER TABLE "stg::firom.load_pack" ADD CONSTRAINT PK_stg_firom_load_pack PRIMARY KEY ("farm_inform_code");



/* DDL FOR firom.load_Pack_all_bckdata */
CREATE TABLE "stg::firom.load_pack_all_bckdata"(
  "farm_inform_code" INT NOT NULL,
  "name" NVARCHAR(40) NULL,
  "subname" NVARCHAR(40) NULL,
  "description" NVARCHAR(50) NULL,
  "minicardcode" NVARCHAR(7) NULL,
  "launch_date_yyyymm" INT NULL,
  "atc_ephmra" NVARCHAR(8) NULL,
  "fotc" NVARCHAR(8) NULL,
  "ean" NVARCHAR(13) NULL,
  "ehibc" NVARCHAR(13) NULL,
  "knmp" NVARCHAR(8) NULL,
  "generic_name" NVARCHAR(50) NULL,
  "form" NVARCHAR(50) NULL,
  "strength_size" BIGINT NULL,
  "strength_unit" NVARCHAR(10) NULL,
  "pack_form" NVARCHAR(12) NULL,
  "pack_size" INT NULL,
  "pack_unit" NVARCHAR(5) NULL,
  "subpackage_size" INT NULL,
  "subpackage_unit" NVARCHAR(5) NULL,
  "farm_inform_participant" NVARCHAR(50) NULL,
  "purchase_channel" NVARCHAR(25) NULL,
  "country_of_origin" NVARCHAR(25) NULL,
  "atc_who" NVARCHAR(8) NULL,
  "ddds_per_pack" INT NULL,
  "registered" NVARCHAR(15) NULL,
  "ur_nr" NVARCHAR(2) NULL,
  "market_coverage" NVARCHAR(50) NULL
);

ALTER TABLE "stg::firom.load_pack_all_bckdata" ADD CONSTRAINT PK_stg_firom_load_pack_all_bckdata PRIMARY KEY ("farm_inform_code");



/* DDL FOR firom.load_Pack_all_bckdata_raw */
CREATE TABLE "stg::firom.load_pack_all_bckdata_raw"(
  "farm_inform_code" INT NOT NULL,
  "name" NVARCHAR(40) NULL,
  "subname" NVARCHAR(40) NULL,
  "description" NVARCHAR(50) NULL,
  "minicardcode" NVARCHAR(7) NULL,
  "launch_date_yyyymm" INT NULL,
  "atc_ephmra" NVARCHAR(8) NULL,
  "fotc" NVARCHAR(8) NULL,
  "ean" NVARCHAR(13) NULL,
  "ehibc" NVARCHAR(13) NULL,
  "knmp" NVARCHAR(8) NULL,
  "generic_name" NVARCHAR(50) NULL,
  "form" NVARCHAR(50) NULL,
  "strength_size" BIGINT NULL,
  "strength_unit" NVARCHAR(10) NULL,
  "pack_form" NVARCHAR(12) NULL,
  "pack_size" INT NULL,
  "pack_unit" NVARCHAR(5) NULL,
  "subpackage_size" INT NULL,
  "subpackage_unit" NVARCHAR(5) NULL,
  "farm_inform_participant" NVARCHAR(50) NULL,
  "purchase_channel" NVARCHAR(25) NULL,
  "country_of_origin" NVARCHAR(25) NULL,
  "atc_who" NVARCHAR(8) NULL,
  "ddds_per_pack" INT NULL,
  "registered" NVARCHAR(15) NULL,
  "ur_nr" NVARCHAR(2) NULL,
  "market_coverage" NVARCHAR(50) NULL,
  "pack_file_name" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::firom.load_pack_all_bckdata_raw" ADD CONSTRAINT PK_stg_firom_load_pack_all_bckdata_raw PRIMARY KEY ("farm_inform_code", "pack_file_name");



/* DDL FOR firom.load_Pack_hist */
CREATE TABLE "stg::firom.load_pack_hist"(
  "farm_inform_code" INT NOT NULL,
  "hist_id" INT NOT NULL,
  "name" NVARCHAR(40) NULL,
  "subname" NVARCHAR(40) NULL,
  "description" NVARCHAR(50) NULL,
  "minicardcode" NVARCHAR(7) NULL,
  "launch_date_yyyymm" INT NULL,
  "atc_ephmra" NVARCHAR(8) NULL,
  "fotc" NVARCHAR(8) NULL,
  "ean" NVARCHAR(13) NULL,
  "ehibc" NVARCHAR(13) NULL,
  "knmp" NVARCHAR(8) NULL,
  "generic_name" NVARCHAR(50) NULL,
  "form" NVARCHAR(50) NULL,
  "strength_size" BIGINT NULL,
  "strength_unit" NVARCHAR(10) NULL,
  "pack_form" NVARCHAR(12) NULL,
  "pack_size" INT NULL,
  "pack_unit" NVARCHAR(5) NULL,
  "subpackage_size" INT NULL,
  "subpackage_unit" NVARCHAR(5) NULL,
  "farm_inform_participant" NVARCHAR(50) NULL,
  "purchase_channel" NVARCHAR(25) NULL,
  "country_of_origin" NVARCHAR(25) NULL,
  "atc_who" NVARCHAR(8) NULL,
  "ddds_per_pack" INT NULL,
  "registered" NVARCHAR(15) NULL,
  "ur_nr" NVARCHAR(2) NULL,
  "market_coverage" NVARCHAR(50) NULL
);

ALTER TABLE "stg::firom.load_pack_hist" ADD CONSTRAINT PK_stg_firom_load_pack_hist PRIMARY KEY ("farm_inform_code", "hist_id");



/* DDL FOR firom.load_PADDS */
CREATE TABLE "stg::firom.load_padds"(
  "padds_load_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "cty" VARCHAR(50) NULL,
  "sseg" VARCHAR(50) NULL,
  "rxotc" VARCHAR(50) NULL,
  "mkt_t" VARCHAR(50) NULL,
  "intrx" VARCHAR(50) NULL,
  "atc4" VARCHAR(50) NULL,
  "nfc" VARCHAR(50) NULL,
  "mol" VARCHAR(500) NULL,
  "mo_co" VARCHAR(50) NULL,
  "m_cnt" VARCHAR(50) NULL,
  "m_lst" VARCHAR(1000) NULL,
  "inprd" VARCHAR(50) NULL,
  "intst" VARCHAR(50) NULL,
  "ipld" VARCHAR(50) NULL,
  "str" VARCHAR(50) NULL,
  "intpc" VARCHAR(50) NULL,
  "prd" VARCHAR(50) NULL,
  "nprd" VARCHAR(50) NULL,
  "prdld" VARCHAR(50) NULL,
  "pck" VARCHAR(50) NULL,
  "pckld" VARCHAR(50) NULL,
  "intre" VARCHAR(50) NULL,
  "lorei" VARCHAR(50) NULL,
  "crp" VARCHAR(50) NULL,
  "mnf" VARCHAR(50) NULL,
  "xdate" VARCHAR(50) NULL,
  "sal_usd" NUMERIC(18,0) NULL,
  "un_un" NUMERIC(18,0) NULL,
  "su_calc_su_calc" NUMERIC(18,0) NULL,
  "cu_cu" NUMERIC(18,0) NULL
);

ALTER TABLE "stg::firom.load_padds" ADD CONSTRAINT PK_stg_firom_load_padds PRIMARY KEY ("padds_load_id");



/* DDL FOR firom.load_PADDS_2 */
CREATE TABLE "stg::firom.load_padds_2"(
  "padds_load_id" INT NOT NULL,
  "cty" VARCHAR(50) NULL,
  "sseg" VARCHAR(50) NULL,
  "rxotc" VARCHAR(50) NULL,
  "mkt_t" VARCHAR(50) NULL,
  "intrx" VARCHAR(50) NULL,
  "atc4" VARCHAR(50) NULL,
  "nfc" VARCHAR(50) NULL,
  "mol" VARCHAR(500) NULL,
  "mo_co" VARCHAR(50) NULL,
  "m_cnt" VARCHAR(50) NULL,
  "m_lst" VARCHAR(1000) NULL,
  "inprd" VARCHAR(50) NULL,
  "intst" VARCHAR(50) NULL,
  "ipld" VARCHAR(50) NULL,
  "str" VARCHAR(50) NULL,
  "intpc" VARCHAR(50) NULL,
  "prd" VARCHAR(50) NULL,
  "nprd" VARCHAR(50) NULL,
  "prdld" VARCHAR(50) NULL,
  "pck" VARCHAR(50) NULL,
  "pckld" VARCHAR(50) NULL,
  "intre" VARCHAR(50) NULL,
  "lorei" VARCHAR(50) NULL,
  "crp" VARCHAR(50) NULL,
  "mnf" VARCHAR(50) NULL,
  "xdate" VARCHAR(50) NULL,
  "sal_usd" NUMERIC(18,0) NULL,
  "un_un" NUMERIC(18,0) NULL,
  "su_calc_su_calc" NUMERIC(18,0) NULL,
  "cu_cu" NUMERIC(18,0) NULL
);

ALTER TABLE "stg::firom.load_padds_2" ADD CONSTRAINT PK_stg_firom_load_padds_2 PRIMARY KEY ("padds_load_id");



/* DDL FOR firom.load_PADDS_20120427 */
CREATE TABLE "stg::firom.load_padds_20120427"(
  "padds_load_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "cty" VARCHAR(255) NULL,
  "sseg" VARCHAR(255) NULL,
  "rxotc" VARCHAR(255) NULL,
  "mkt_t" VARCHAR(255) NULL,
  "intrx" VARCHAR(255) NULL,
  "atc4" VARCHAR(255) NULL,
  "nfc" VARCHAR(255) NULL,
  "mol" VARCHAR(500) NULL,
  "mo_co" VARCHAR(255) NULL,
  "m_cnt" VARCHAR(255) NULL,
  "m_lst" VARCHAR(1000) NULL,
  "inprd" VARCHAR(255) NULL,
  "intst" VARCHAR(255) NULL,
  "ipld" VARCHAR(255) NULL,
  "str" VARCHAR(255) NULL,
  "intpc" VARCHAR(255) NULL,
  "prd" VARCHAR(255) NULL,
  "nprd" VARCHAR(255) NULL,
  "prdld" VARCHAR(255) NULL,
  "pck" VARCHAR(255) NULL,
  "pckld" VARCHAR(255) NULL,
  "intre" VARCHAR(255) NULL,
  "lorei" VARCHAR(255) NULL,
  "crp" VARCHAR(255) NULL,
  "mnf" VARCHAR(255) NULL,
  "xdate" VARCHAR(255) NULL,
  "sal_usd" NUMERIC(18,0) NULL,
  "un_un" NUMERIC(18,0) NULL,
  "su_calc_su_calc" NUMERIC(18,0) NULL,
  "cu_cu" NUMERIC(18,0) NULL
);

ALTER TABLE "stg::firom.load_padds_20120427" ADD CONSTRAINT PK_stg_firom_load_padds_20120427 PRIMARY KEY ("padds_load_id");



/* DDL FOR firom.load_Price */
CREATE TABLE "stg::firom.load_price"(
  "farm_inform_code" INT NOT NULL,
  "period_yyyymm" INT NOT NULL,
  "price_code" NVARCHAR(3) NOT NULL,
  "price_euro_cents" INT NULL
);

ALTER TABLE "stg::firom.load_price" ADD CONSTRAINT PK_stg_firom_load_price PRIMARY KEY ("farm_inform_code", "period_yyyymm", "price_code");



/* DDL FOR firom.load_Price_all_bckdata */
CREATE TABLE "stg::firom.load_price_all_bckdata"(
  "farm_inform_code" INT NOT NULL,
  "period_yyyymm" INT NOT NULL,
  "price_code" NVARCHAR(3) NOT NULL,
  "price_euro_cents" INT NULL
);

ALTER TABLE "stg::firom.load_price_all_bckdata" ADD CONSTRAINT PK_stg_firom_load_price_all_bckdata PRIMARY KEY ("farm_inform_code", "period_yyyymm", "price_code");



/* DDL FOR firom.load_Price_hist */
CREATE TABLE "stg::firom.load_price_hist"(
  "farm_inform_code" INT NOT NULL,
  "period_yyyymm" INT NOT NULL,
  "price_code" NVARCHAR(3) NOT NULL,
  "hist_id" INT NOT NULL,
  "price_euro_cents" INT NULL
);

ALTER TABLE "stg::firom.load_price_hist" ADD CONSTRAINT PK_stg_firom_load_price_hist PRIMARY KEY ("farm_inform_code", "period_yyyymm", "price_code", "hist_id");



/* DDL FOR firom.maint_ATC4_lookup */
CREATE TABLE "stg::firom.maint_atc4_lookup"(
  "maint_atc4_lookup_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "atc4" NVARCHAR(100) NOT NULL
);

ALTER TABLE "stg::firom.maint_atc4_lookup" ADD CONSTRAINT PK_stg_firom_maint_atc4_lookup PRIMARY KEY ("maint_atc4_lookup_id");



/* DDL FOR firom.maint_CRP_list */
CREATE TABLE "stg::firom.maint_crp_list"(
  "maint_crp_list_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "corporation_list" NVARCHAR(4000) NOT NULL
);

ALTER TABLE "stg::firom.maint_crp_list" ADD CONSTRAINT PK_stg_firom_maint_crp_list PRIMARY KEY ("maint_crp_list_id");



/* DDL FOR firom.maint_CRP_lookup */
CREATE TABLE "stg::firom.maint_crp_lookup"(
  "maint_crp_lookup_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "corporation" NVARCHAR(100) NOT NULL,
  "corporation_percent" NUMERIC(10,5) NOT NULL DEFAULT 100.00,
  "corporation_list" NVARCHAR(4000) NULL,
  "maint_crp_list_id" INT NOT NULL
);

ALTER TABLE "stg::firom.maint_crp_lookup" ADD CONSTRAINT PK_stg_firom_maint_crp_lookup PRIMARY KEY ("maint_crp_lookup_id");



/* DDL FOR firom.maint_GenericName_lookup */
CREATE TABLE "stg::firom.maint_generic_name_lookup"(
  "generic_name_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "generic_name" NVARCHAR(50) NOT NULL,
  "maint_mol_list_id" INT NULL,
  "mol_comment" NVARCHAR(4000) NULL,
  "mol_changed_at" TIMESTAMP NULL,
  "mol_changed_by" NVARCHAR(150) NULL,
  "mol_condition" NVARCHAR(4000) NULL
);

ALTER TABLE "stg::firom.maint_generic_name_lookup" ADD CONSTRAINT PK_stg_firom_maint_generic_name_lookup PRIMARY KEY ("generic_name_id");



/* DDL FOR firom.maint_IntPck_lookup */
CREATE TABLE "stg::firom.maint_intpck_lookup"(
  "maint_intpck_lookup_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "intpck" NVARCHAR(100) NOT NULL
);

ALTER TABLE "stg::firom.maint_intpck_lookup" ADD CONSTRAINT PK_stg_firom_maint_intpck_lookup PRIMARY KEY ("maint_intpck_lookup_id");



/* DDL FOR firom.maint_IntProd_lookup */
CREATE TABLE "stg::firom.maint_intprod_lookup"(
  "maint_intprod_lookup_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "intprod" NVARCHAR(100) NOT NULL
);

ALTER TABLE "stg::firom.maint_intprod_lookup" ADD CONSTRAINT PK_stg_firom_maint_intprod_lookup PRIMARY KEY ("maint_intprod_lookup_id");



/* DDL FOR firom.maint_IntStr_lookup */
CREATE TABLE "stg::firom.maint_intstr_lookup"(
  "maint_intstr_lookup_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "intstr" NVARCHAR(100) NOT NULL
);

ALTER TABLE "stg::firom.maint_intstr_lookup" ADD CONSTRAINT PK_stg_firom_maint_intstr_lookup PRIMARY KEY ("maint_intstr_lookup_id");



/* DDL FOR firom.maint_MNF */
CREATE TABLE "stg::firom.maint_mnf"(
  "maint_mnf_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "manufacturer" NVARCHAR(50) NOT NULL,
  "sales_eur_last_mat" BIGINT NULL,
  "sales_range_last_mat" NVARCHAR(50) NULL,
  "maint_crp_list_id" INT NULL,
  "crp_comment" NVARCHAR(4000) NULL,
  "crp_changed_at" TIMESTAMP NULL,
  "crp_changed_by" NVARCHAR(150) NULL,
  "crp_condition" NVARCHAR(4000) NULL
);

ALTER TABLE "stg::firom.maint_mnf" ADD CONSTRAINT PK_stg_firom_maint_mnf PRIMARY KEY ("maint_mnf_id");



/* DDL FOR firom.maint_MNF_bck */
CREATE TABLE "stg::firom.maint_mnf_bck"(
  "maint_mnf_id" INT NOT NULL,
  "hist_id" INT NOT NULL,
  "manufacturer" NVARCHAR(50) NOT NULL,
  "sales_eur_last_mat" BIGINT NULL,
  "sales_range_last_mat" NVARCHAR(50) NULL,
  "maint_crp_list_id" INT NULL,
  "crp_comment" NVARCHAR(4000) NULL,
  "crp_changed_at" TIMESTAMP NULL,
  "crp_changed_by" NVARCHAR(150) NULL,
  "crp_condition" NVARCHAR(4000) NULL
);

ALTER TABLE "stg::firom.maint_mnf_bck" ADD CONSTRAINT PK_stg_firom_maint_mnf_bck PRIMARY KEY ("maint_mnf_id", "hist_id");



/* DDL FOR firom.maint_Mol_list */
CREATE TABLE "stg::firom.maint_mol_list"(
  "maint_mol_list_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "mol_list" NVARCHAR(4000) NOT NULL
);

ALTER TABLE "stg::firom.maint_mol_list" ADD CONSTRAINT PK_stg_firom_maint_mol_list PRIMARY KEY ("maint_mol_list_id");



/* DDL FOR firom.maint_Mol_lookup */
CREATE TABLE "stg::firom.maint_mol_lookup"(
  "maint_mol_lookup_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "mol" NVARCHAR(100) NOT NULL,
  "mol_list" NVARCHAR(4000) NULL,
  "maint_mol_list_id" INT NOT NULL
);

ALTER TABLE "stg::firom.maint_mol_lookup" ADD CONSTRAINT PK_stg_firom_maint_mol_lookup PRIMARY KEY ("maint_mol_lookup_id");



/* DDL FOR firom.maint_Name_lookup */
CREATE TABLE "stg::firom.maint_name_lookup"(
  "name_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "name" NVARCHAR(40) NOT NULL,
  "maint_mol_list_id" INT NULL,
  "mol_comment" NVARCHAR(4000) NULL,
  "mol_changed_at" TIMESTAMP NULL,
  "mol_changed_by" NVARCHAR(150) NULL,
  "mol_condition" NVARCHAR(4000) NULL
);

ALTER TABLE "stg::firom.maint_name_lookup" ADD CONSTRAINT PK_stg_firom_maint_name_lookup PRIMARY KEY ("name_id");



/* DDL FOR firom.maint_NFC_lookup */
CREATE TABLE "stg::firom.maint_nfc_lookup"(
  "maint_nfc_lookup_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "nfc" NVARCHAR(100) NOT NULL
);

ALTER TABLE "stg::firom.maint_nfc_lookup" ADD CONSTRAINT PK_stg_firom_maint_nfc_lookup PRIMARY KEY ("maint_nfc_lookup_id");



/* DDL FOR firom.maint_Pack */
CREATE TABLE "stg::firom.maint_pack"(
  "pack_id" INT NOT NULL,
  "cty" NVARCHAR(50) NOT NULL,
  "padds_pack_id" INT NULL,
  "padds_matching_type" NVARCHAR(50) NULL,
  "name" NVARCHAR(40) NULL,
  "subname" NVARCHAR(40) NULL,
  "description" NVARCHAR(50) NULL,
  "minicardcode" NVARCHAR(7) NULL,
  "launch_date_yyyymm" INT NULL,
  "atc_ephmra" NVARCHAR(8) NULL,
  "fotc" NVARCHAR(8) NULL,
  "ean" NVARCHAR(13) NULL,
  "ehibc" NVARCHAR(13) NULL,
  "knmp" NVARCHAR(8) NULL,
  "generic_name" NVARCHAR(50) NULL,
  "form" NVARCHAR(50) NULL,
  "strength_size" BIGINT NULL,
  "strength_unit" NVARCHAR(10) NULL,
  "pack_form" NVARCHAR(12) NULL,
  "pack_size" INT NULL,
  "pack_unit" NVARCHAR(5) NULL,
  "subpackage_size" INT NULL,
  "subpackage_unit" NVARCHAR(5) NULL,
  "farm_inform_participant" NVARCHAR(50) NULL,
  "purchase_channel" NVARCHAR(25) NULL,
  "country_of_origin" NVARCHAR(25) NULL,
  "atc_who" NVARCHAR(8) NULL,
  "ddds_per_pack" INT NULL,
  "registered" NVARCHAR(15) NULL,
  "ur_nr" NVARCHAR(2) NULL,
  "market_coverage" NVARCHAR(50) NULL,
  "prd_ldate_yyymm" INT NULL,
  "intprd_ldate_yyyymm" INT NULL,
  "sales_eur_last_mat" BIGINT NULL,
  "sales_range_last_mat" NVARCHAR(50) NULL,
  "maint_intprod_lookup_id" INT NULL,
  "intprod_comment" NVARCHAR(4000) NULL,
  "intprod_changed_at" TIMESTAMP NULL,
  "intprod_changed_by" NVARCHAR(150) NULL,
  "intprod_condition" NVARCHAR(4000) NULL,
  "maint_mol_list_id" INT NULL,
  "mol_comment" NVARCHAR(4000) NULL,
  "mol_changed_at" TIMESTAMP NULL,
  "mol_changed_by" NVARCHAR(150) NULL,
  "mol_condition" NVARCHAR(4000) NULL,
  "maint_atc4_lookup_id" INT NULL,
  "atc4_comment" NVARCHAR(4000) NULL,
  "atc4_changed_at" TIMESTAMP NULL,
  "atc4_changed_by" NVARCHAR(150) NULL,
  "atc4_condition" NVARCHAR(4000) NULL,
  "maint_subsegment_lookup_id" INT NULL,
  "subsegment_comment" NVARCHAR(4000) NULL,
  "subsegment_changed_at" TIMESTAMP NULL,
  "subsegment_changed_by" NVARCHAR(150) NULL,
  "subsegment_condition" NVARCHAR(4000) NULL,
  "maint_intstr_lookup_id" INT NULL,
  "intstr_comment" NVARCHAR(4000) NULL,
  "intstr_changed_at" TIMESTAMP NULL,
  "intstr_changed_by" NVARCHAR(150) NULL,
  "intstr_condition" NVARCHAR(4000) NULL,
  "maint_intpck_lookup_id" INT NULL,
  "intpck_comment" NVARCHAR(4000) NULL,
  "intpck_changed_at" TIMESTAMP NULL,
  "intpck_changed_by" NVARCHAR(150) NULL,
  "intpck_condition" NVARCHAR(4000) NULL,
  "maint_nfc_lookup_id" INT NULL,
  "nfc_comment" NVARCHAR(4000) NULL,
  "nfc_changed_at" TIMESTAMP NULL,
  "nfc_changed_by" NVARCHAR(150) NULL,
  "nfc_condition" NVARCHAR(4000) NULL,
  "orig_quarter" INT NOT NULL DEFAULT 201006,
  "su_factor" DECIMAL(24,6) NULL DEFAULT 0,
  "cu_factor" DECIMAL(24,6) NULL DEFAULT 0,
  "atc4" NVARCHAR(100) NULL,
  "nfc" NVARCHAR(100) NULL,
  "intprd_ldate_yyyymm_bck" INT NOT NULL DEFAULT 0,
  "pack_replaced" NVARCHAR(100) NULL,
  "changed_last_qtr_id" INT NULL DEFAULT 200000,
  "changed_description" NVARCHAR(255) NULL,
  "status_flag" INT NULL DEFAULT 0,
  "su_factor_rule" NVARCHAR(255) NULL
);

ALTER TABLE "stg::firom.maint_pack" ADD CONSTRAINT PK_stg_firom_maint_pack PRIMARY KEY ("pack_id", "cty");



/* DDL FOR firom.maint_Pack_bck */
CREATE TABLE "stg::firom.maint_pack_bck"(
  "pack_id" INT NOT NULL,
  "cty" NVARCHAR(50) NOT NULL,
  "hist_id" INT NOT NULL,
  "padds_pack_id" INT NULL,
  "padds_matching_type" NVARCHAR(50) NULL,
  "name" NVARCHAR(40) NULL,
  "subname" NVARCHAR(40) NULL,
  "description" NVARCHAR(50) NULL,
  "minicardcode" NVARCHAR(7) NULL,
  "launch_date_yyyymm" INT NULL,
  "atc_ephmra" NVARCHAR(8) NULL,
  "fotc" NVARCHAR(8) NULL,
  "ean" NVARCHAR(13) NULL,
  "ehibc" NVARCHAR(13) NULL,
  "knmp" NVARCHAR(8) NULL,
  "generic_name" NVARCHAR(50) NULL,
  "form" NVARCHAR(50) NULL,
  "strength_size" BIGINT NULL,
  "strength_unit" NVARCHAR(10) NULL,
  "pack_form" NVARCHAR(12) NULL,
  "pack_size" INT NULL,
  "pack_unit" NVARCHAR(5) NULL,
  "subpackage_size" INT NULL,
  "subpackage_unit" NVARCHAR(5) NULL,
  "farm_inform_participant" NVARCHAR(50) NULL,
  "purchase_channel" NVARCHAR(25) NULL,
  "country_of_origin" NVARCHAR(25) NULL,
  "atc_who" NVARCHAR(8) NULL,
  "ddds_per_pack" INT NULL,
  "registered" NVARCHAR(15) NULL,
  "ur_nr" NVARCHAR(2) NULL,
  "market_coverage" NVARCHAR(50) NULL,
  "prd_ldate_yyymm" INT NULL,
  "intprd_ldate_yyyymm" INT NULL,
  "sales_eur_last_mat" BIGINT NULL,
  "sales_range_last_mat" NVARCHAR(50) NULL,
  "maint_intprod_lookup_id" INT NULL,
  "intprod_comment" NVARCHAR(4000) NULL,
  "intprod_changed_at" TIMESTAMP NULL,
  "intprod_changed_by" NVARCHAR(150) NULL,
  "intprod_condition" NVARCHAR(4000) NULL,
  "maint_mol_list_id" INT NULL,
  "mol_comment" NVARCHAR(4000) NULL,
  "mol_changed_at" TIMESTAMP NULL,
  "mol_changed_by" NVARCHAR(150) NULL,
  "mol_condition" NVARCHAR(4000) NULL,
  "maint_atc4_lookup_id" INT NULL,
  "atc4_comment" NVARCHAR(4000) NULL,
  "atc4_changed_at" TIMESTAMP NULL,
  "atc4_changed_by" NVARCHAR(150) NULL,
  "atc4_condition" NVARCHAR(4000) NULL,
  "maint_subsegment_lookup_id" INT NULL,
  "subsegment_comment" NVARCHAR(4000) NULL,
  "subsegment_changed_at" TIMESTAMP NULL,
  "subsegment_changed_by" NVARCHAR(150) NULL,
  "subsegment_condition" NVARCHAR(4000) NULL,
  "maint_intstr_lookup_id" INT NULL,
  "intstr_comment" NVARCHAR(4000) NULL,
  "intstr_changed_at" TIMESTAMP NULL,
  "intstr_changed_by" NVARCHAR(150) NULL,
  "intstr_condition" NVARCHAR(4000) NULL,
  "maint_intpck_lookup_id" INT NULL,
  "intpck_comment" NVARCHAR(4000) NULL,
  "intpck_changed_at" TIMESTAMP NULL,
  "intpck_changed_by" NVARCHAR(150) NULL,
  "intpck_condition" NVARCHAR(4000) NULL,
  "maint_nfc_lookup_id" INT NULL,
  "nfc_comment" NVARCHAR(4000) NULL,
  "nfc_changed_at" TIMESTAMP NULL,
  "nfc_changed_by" NVARCHAR(150) NULL,
  "nfc_condition" NVARCHAR(4000) NULL,
  "orig_quarter" INT NOT NULL DEFAULT 201006,
  "su_factor" DECIMAL(24,6) NULL,
  "cu_factor" DECIMAL(24,6) NULL
);

ALTER TABLE "stg::firom.maint_pack_bck" ADD CONSTRAINT PK_stg_firom_maint_pack_bck PRIMARY KEY ("pack_id", "cty", "hist_id");



/* DDL FOR firom.maint_pack_replaced_lookup */
CREATE TABLE "stg::firom.maint_pack_replaced_lookup"(
  "maint_pack_replaced_lookup_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "pack_replaced" NVARCHAR(100) NOT NULL,
  "nfc" NVARCHAR(100) NOT NULL
);

ALTER TABLE "stg::firom.maint_pack_replaced_lookup" ADD CONSTRAINT PK_stg_firom_maint_pack_replaced_lookup PRIMARY KEY ("maint_pack_replaced_lookup_id");



/* DDL FOR firom.maint_SubSegment_lookup */
CREATE TABLE "stg::firom.maint_subsegment_lookup"(
  "maint_subsegment_lookup_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "subsegment" NVARCHAR(100) NOT NULL
);

ALTER TABLE "stg::firom.maint_subsegment_lookup" ADD CONSTRAINT PK_stg_firom_maint_subsegment_lookup PRIMARY KEY ("maint_subsegment_lookup_id");



/* DDL FOR firom.match_Pack */
CREATE TABLE "stg::firom.match_pack"(
  "firom_pack_id" INT NOT NULL,
  "cty" NVARCHAR(50) NOT NULL,
  "firom_prd" NVARCHAR(40) NOT NULL,
  "padds_pack_id" INT NOT NULL,
  "firom_packs_per_padds_pack" INT NOT NULL,
  "padds_packs_per_firom_pack" INT NOT NULL
);

ALTER TABLE "stg::firom.match_pack" ADD CONSTRAINT PK_stg_firom_match_pack PRIMARY KEY ("firom_pack_id", "cty", "padds_pack_id");



/* DDL FOR firom.match_Pack_bck */
CREATE TABLE "stg::firom.match_pack_bck"(
  "firom_pack_id" INT NOT NULL,
  "cty" NVARCHAR(50) NOT NULL,
  "hist_id" INT NOT NULL,
  "firom_prd" NVARCHAR(40) NOT NULL,
  "padds_pack_id" INT NOT NULL,
  "firom_packs_per_padds_pack" INT NOT NULL,
  "padds_packs_per_firom_pack" INT NOT NULL
);

ALTER TABLE "stg::firom.match_pack_bck" ADD CONSTRAINT PK_stg_firom_match_pack_bck PRIMARY KEY ("firom_pack_id", "cty", "hist_id", "padds_pack_id");



/* DDL FOR firom.pack_replaced_init_tmp */
CREATE TABLE "stg::firom.pack_replaced_init_tmp"(
  "pack_replaced" NVARCHAR(100) NOT NULL,
  "old_id" INT NOT NULL,
  "old_nfc" NVARCHAR(100) NOT NULL,
  "new_id" INT NOT NULL,
  "new_nfc" NVARCHAR(100) NOT NULL,
  "nfc_changed_by" NVARCHAR(150) NULL,
  "nfc_comment" NVARCHAR(4000) NULL,
  "scnt" INT NOT NULL
);



/* DDL FOR firom.PADDS_pack */
CREATE TABLE "stg::firom.padds_pack"(
  "padds_pack_id" INT NOT NULL GENERATED BY DEFAULT AS IDENTITY,
  "cty" VARCHAR(50) NULL,
  "sseg" VARCHAR(50) NULL,
  "rxotc" VARCHAR(50) NULL,
  "mkt_t" VARCHAR(50) NULL,
  "intrx" VARCHAR(50) NULL,
  "atc4" VARCHAR(50) NULL,
  "nfc" VARCHAR(50) NULL,
  "mo_co" VARCHAR(50) NULL,
  "m_cnt" VARCHAR(50) NULL,
  "m_lst" VARCHAR(1000) NULL,
  "inprd" VARCHAR(50) NULL,
  "intst" VARCHAR(50) NULL,
  "ipld" VARCHAR(50) NULL,
  "str" VARCHAR(50) NULL,
  "intpc" VARCHAR(50) NULL,
  "prd" VARCHAR(50) NULL,
  "nprd" VARCHAR(50) NULL,
  "prdld" VARCHAR(50) NULL,
  "pck" VARCHAR(50) NULL,
  "pckld" VARCHAR(50) NULL,
  "intre" VARCHAR(50) NULL,
  "lorei" VARCHAR(50) NULL,
  "crp_list" VARCHAR(100) NULL,
  "mnf" VARCHAR(50) NULL,
  "sal_usd_last_mat" BIGINT NULL,
  "un_last_mat" BIGINT NULL,
  "un_abs_all" BIGINT NULL
);

ALTER TABLE "stg::firom.padds_pack" ADD CONSTRAINT PK_stg_firom_padds_pack PRIMARY KEY ("padds_pack_id");



/* DDL FOR firom.PADDS_pack_2 */
CREATE TABLE "stg::firom.padds_pack_2"(
  "padds_pack_id" INT NOT NULL,
  "cty" VARCHAR(50) NULL,
  "sseg" VARCHAR(50) NULL,
  "rxotc" VARCHAR(50) NULL,
  "mkt_t" VARCHAR(50) NULL,
  "intrx" VARCHAR(50) NULL,
  "atc4" VARCHAR(50) NULL,
  "nfc" VARCHAR(50) NULL,
  "mo_co" VARCHAR(50) NULL,
  "m_cnt" VARCHAR(50) NULL,
  "m_lst" VARCHAR(1000) NULL,
  "inprd" VARCHAR(50) NULL,
  "intst" VARCHAR(50) NULL,
  "ipld" VARCHAR(50) NULL,
  "str" VARCHAR(50) NULL,
  "intpc" VARCHAR(50) NULL,
  "prd" VARCHAR(50) NULL,
  "nprd" VARCHAR(50) NULL,
  "prdld" VARCHAR(50) NULL,
  "pck" VARCHAR(50) NULL,
  "pckld" VARCHAR(50) NULL,
  "intre" VARCHAR(50) NULL,
  "lorei" VARCHAR(50) NULL,
  "crp_list" VARCHAR(100) NULL,
  "mnf" VARCHAR(50) NULL,
  "sal_usd_last_mat" BIGINT NULL,
  "un_last_mat" BIGINT NULL,
  "un_abs_all" BIGINT NULL
);

ALTER TABLE "stg::firom.padds_pack_2" ADD CONSTRAINT PK_stg_firom_padds_pack_2 PRIMARY KEY ("padds_pack_id");



/* DDL FOR firom.t_firom_periods */
CREATE TABLE "stg::firom.t_firom_periods"(
  "first_month" INT NOT NULL,
  "last_month" INT NOT NULL,
  "first_full_qtr" INT NOT NULL,
  "last_full_qtr" INT NOT NULL
);



/* DDL FOR firom.temp_c_compare */
CREATE TABLE "stg::firom.temp_c_compare"(
  "ml_id" INT NOT NULL,
  "list_pkey" NVARCHAR(255) NOT NULL,
  "oldvalue" NVARCHAR(255) NOT NULL,
  "newvalue" NVARCHAR(255) NOT NULL
);



