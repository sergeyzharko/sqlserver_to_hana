/* DDL FOR cup.maint_crp_lookup */
ALTER TABLE "stg::cup.maint_crp_lookup" ADD CONSTRAINT "FK_stg_cup_maint_crp_lookup_maint_crp_lookup_maint_crp_list_id" FOREIGN KEY ("maint_crp_list_id") REFERENCES "stg::cup.maint_crp_list"("maint_crp_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR cup.maint_mol */
ALTER TABLE "stg::cup.maint_mol" ADD CONSTRAINT "FK_stg_cup_maint_mol_maint_mol_maint_mol_list_id" FOREIGN KEY ("maint_mol_list_id") REFERENCES "stg::cup.maint_mol_list"("maint_mol_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR cup.maint_mol_lookup */
ALTER TABLE "stg::cup.maint_mol_lookup" ADD CONSTRAINT "FK_stg_cup_maint_mol_lookup_maint_mol_lookup_maint_mol_list_id" FOREIGN KEY ("maint_mol_list_id") REFERENCES "stg::cup.maint_mol_list"("maint_mol_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR cup.maint_nfc */
ALTER TABLE "stg::cup.maint_nfc" ADD CONSTRAINT "FK_stg_cup_maint_nfc_maint_nfc_maint_nfc_lookup_id" FOREIGN KEY ("maint_nfc_lookup_id") REFERENCES "stg::cup.maint_nfc_lookup"("maint_nfc_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR cup.maint_pack */
ALTER TABLE "stg::cup.maint_pack" ADD CONSTRAINT "FK_stg_cup_maint_pack_maint_pack_maint_atc4_lookup_id" FOREIGN KEY ("maint_atc4_lookup_id") REFERENCES "stg::cup.maint_atc4_lookup"("maint_atc4_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::cup.maint_pack" ADD CONSTRAINT "FK_stg_cup_maint_pack_maint_pack_maint_intpck_lookup_id" FOREIGN KEY ("maint_intpck_lookup_id") REFERENCES "stg::cup.maint_intpck_lookup"("maint_intpck_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::cup.maint_pack" ADD CONSTRAINT "FK_stg_cup_maint_pack_maint_pack_maint_intprd_lookup_id" FOREIGN KEY ("maint_intprd_lookup_id") REFERENCES "stg::cup.maint_intprd_lookup"("maint_intprd_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::cup.maint_pack" ADD CONSTRAINT "FK_stg_cup_maint_pack_maint_pack_maint_intstr_lookup_id" FOREIGN KEY ("maint_intstr_lookup_id") REFERENCES "stg::cup.maint_intstr_lookup"("maint_intstr_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR cup.maint_su_factor */
ALTER TABLE "stg::cup.maint_su_factor" ADD CONSTRAINT "FK_stg_cup_maint_su_factor_maint_su_factor_su_factor_lookup_id" FOREIGN KEY ("su_factor_lookup_id") REFERENCES "stg::cup.maint_su_factor_lookup"("maint_suf_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
