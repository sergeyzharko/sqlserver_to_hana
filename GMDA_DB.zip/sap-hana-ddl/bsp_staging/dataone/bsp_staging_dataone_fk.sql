/* DDL FOR dataone.maint_rad_internal_package */
ALTER TABLE "stg::dataone.maint_rad_internal_package" ADD CONSTRAINT "FK_stg_dataone_maint_rad_internal_package_maint_rad_internal_package_maint_excl_lookup_id" FOREIGN KEY ("maint_excl_lookup_id") REFERENCES "stg::dataone.maint_excl_lookup"("maint_excl_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR dataone.maint_rad_internal_package_hist */
ALTER TABLE "stg::dataone.maint_rad_internal_package_hist" ADD CONSTRAINT "FK_stg_dataone_maint_rad_internal_package_hist_maint_rad_internal_package_hist_hist_id" FOREIGN KEY ("hist_id") REFERENCES "stg::dataone.rad_internal_hist"("hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "stg::dataone.maint_rad_internal_package_hist" ADD CONSTRAINT "FK_stg_dataone_maint_rad_internal_package_hist_maint_rad_internal_package_hist_maint_excl_lookup_id" FOREIGN KEY ("maint_excl_lookup_id") REFERENCES "stg::dataone.maint_excl_lookup"("maint_excl_lookup_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR dataone.rad_internal_data_hist */
ALTER TABLE "stg::dataone.rad_internal_data_hist" ADD CONSTRAINT "FK_stg_dataone_rad_internal_data_hist_rad_internal_data_hist_hist_id" FOREIGN KEY ("hist_id") REFERENCES "stg::dataone.rad_internal_hist"("hist_id") ON DELETE RESTRICT ON UPDATE RESTRICT;