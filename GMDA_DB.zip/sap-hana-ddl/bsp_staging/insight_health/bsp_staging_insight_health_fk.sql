/* DDL FOR insight_health.maint_CRP_lookup */
ALTER TABLE "stg::insight_health.maint_crp_lookup" ADD CONSTRAINT "FK_stg_insight_health_maint_crp_lookup_maint_crp_lookup_maint_crp_list_id" FOREIGN KEY ("maint_crp_list_id") REFERENCES "stg::insight_health.maint_crp_list"("maint_crp_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

 /* DDL FOR insight_health.maint_Mol_lookup */
ALTER TABLE "stg::insight_health.maint_mol_lookup" ADD CONSTRAINT "FK_stg_insight_health_maint_mol_lookup_maint_mol_lookup_maint_mol_list_id" FOREIGN KEY ("maint_mol_list_id") REFERENCES "stg::insight_health.maint_mol_list"("maint_mol_list_id") ON DELETE RESTRICT ON UPDATE RESTRICT;