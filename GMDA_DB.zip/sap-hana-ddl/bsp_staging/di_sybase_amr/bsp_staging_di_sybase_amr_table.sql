/* DDL FOR di_sybase_amr.AMR_activity */
CREATE TABLE "stg::di_sybase_amr.amr_activity"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_activity" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_activity PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_activity_units */
CREATE TABLE "stg::di_sybase_amr.amr_activity_units"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_activity_units" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_activity_units PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_age */
CREATE TABLE "stg::di_sybase_amr.amr_age"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_age" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_age PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_amr_procedure */
CREATE TABLE "stg::di_sybase_amr.amr_amr_procedure"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_amr_procedure" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_amr_procedure PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_concentration */
CREATE TABLE "stg::di_sybase_amr.amr_concentration"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_concentration" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_concentration PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_contrast */
CREATE TABLE "stg::di_sybase_amr.amr_contrast"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_contrast" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_contrast PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_contrast_source */
CREATE TABLE "stg::di_sybase_amr.amr_contrast_source"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_contrast_source" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_contrast_source PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_country */
CREATE TABLE "stg::di_sybase_amr.amr_country"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_country" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_country PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_direct_source */
CREATE TABLE "stg::di_sybase_amr.amr_direct_source"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_direct_source" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_direct_source PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_dose_form */
CREATE TABLE "stg::di_sybase_amr.amr_dose_form"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_dose_form" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_dose_form PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_enhancement */
CREATE TABLE "stg::di_sybase_amr.amr_enhancement"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_enhancement" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_enhancement PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_fact */
CREATE TABLE "stg::di_sybase_amr.amr_fact"(
  "period_key" INT NULL,
  "fact_base_pck_pkey" INT NULL,
  "record_type_pkey" INT NULL,
  "enhancement_pkey" INT NULL,
  "country_pkey" INT NULL,
  "market_pkey" INT NULL,
  "modality_pkey" INT NULL,
  "amr_procedure_pkey" INT NULL,
  "contrast_pkey" INT NULL,
  "concentration_pkey" INT NULL,
  "marketer_pkey" INT NULL,
  "sex_pkey" INT NULL,
  "age_pkey" INT NULL,
  "reason_pkey" INT NULL,
  "referring_md_pkey" INT NULL,
  "patient_status_pkey" INT NULL,
  "power_injector_pkey" INT NULL,
  "mri_injections_pkey" INT NULL,
  "osmolarity_pkey" INT NULL,
  "gi_marker_pkey" INT NULL,
  "gi_marker_roa_pkey" INT NULL,
  "contrast_source_pkey" INT NULL,
  "rph_src_pkey" INT NULL,
  "direct_source_pkey" INT NULL,
  "dose_form_pkey" INT NULL,
  "activity_pkey" INT NULL,
  "activity_units_pkey" INT NULL,
  "mp_inj_seq_pkey" INT NULL,
  "mp_stress_seq_pkey" INT NULL,
  "stress_mthd_pkey" INT NULL,
  "stress_phrm_pkey" INT NULL,
  "location_hsp_pkey" INT NULL,
  "reas_contrst_pkey" INT NULL,
  "mp_images_hrs_pkey" INT NULL,
  "mp_gated_wall_pkey" INT NULL,
  "rc_cnt_pck" NUMERIC(13,0) NULL,
  "grams_of_iodine_admin" NUMERIC(27,14) NULL,
  "grams_of_iodine_opened" NUMERIC(27,14) NULL,
  "mls_administered" NUMERIC(27,14) NULL,
  "mls_opened" NUMERIC(27,14) NULL,
  "volume" NUMERIC(27,14) NULL
);



/* DDL FOR di_sybase_amr.AMR_gi_marker */
CREATE TABLE "stg::di_sybase_amr.amr_gi_marker"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_gi_marker" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_gi_marker PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_gi_marker_roa */
CREATE TABLE "stg::di_sybase_amr.amr_gi_marker_roa"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_gi_marker_roa" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_gi_marker_roa PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_group_element */
CREATE TABLE "stg::di_sybase_amr.amr_group_element"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_group_element" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_group_element PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_location_hsp */
CREATE TABLE "stg::di_sybase_amr.amr_location_hsp"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_location_hsp" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_location_hsp PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_market */
CREATE TABLE "stg::di_sybase_amr.amr_market"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_market" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_market PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_marketer */
CREATE TABLE "stg::di_sybase_amr.amr_marketer"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_marketer" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_marketer PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_modality */
CREATE TABLE "stg::di_sybase_amr.amr_modality"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_modality" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_modality PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_mp_gated_wall */
CREATE TABLE "stg::di_sybase_amr.amr_mp_gated_wall"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_mp_gated_wall" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_mp_gated_wall PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_mp_images_hrs */
CREATE TABLE "stg::di_sybase_amr.amr_mp_images_hrs"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_mp_images_hrs" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_mp_images_hrs PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_mp_inj_seq */
CREATE TABLE "stg::di_sybase_amr.amr_mp_inj_seq"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_mp_inj_seq" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_mp_inj_seq PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_mp_stress_seq */
CREATE TABLE "stg::di_sybase_amr.amr_mp_stress_seq"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_mp_stress_seq" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_mp_stress_seq PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_mri_injections */
CREATE TABLE "stg::di_sybase_amr.amr_mri_injections"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_mri_injections" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_mri_injections PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_osmolarity */
CREATE TABLE "stg::di_sybase_amr.amr_osmolarity"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_osmolarity" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_osmolarity PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_patient_status */
CREATE TABLE "stg::di_sybase_amr.amr_patient_status"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_patient_status" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_patient_status PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_period */
CREATE TABLE "stg::di_sybase_amr.amr_period"(
  "base_period_pkey" INT NULL,
  "period_descr" NVARCHAR(80) NULL
);



/* DDL FOR di_sybase_amr.AMR_pkg_size */
CREATE TABLE "stg::di_sybase_amr.amr_pkg_size"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_pkg_size" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_pkg_size PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_pkg_type */
CREATE TABLE "stg::di_sybase_amr.amr_pkg_type"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_pkg_type" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_pkg_type PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_power_injector */
CREATE TABLE "stg::di_sybase_amr.amr_power_injector"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_power_injector" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_power_injector PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_reas_contrst */
CREATE TABLE "stg::di_sybase_amr.amr_reas_contrst"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_reas_contrst" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_reas_contrst PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_reason */
CREATE TABLE "stg::di_sybase_amr.amr_reason"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_reason" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_reason PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_record_type */
CREATE TABLE "stg::di_sybase_amr.amr_record_type"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_record_type" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_record_type PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_referring_md */
CREATE TABLE "stg::di_sybase_amr.amr_referring_md"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_referring_md" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_referring_md PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_rph_multi_dose_src */
CREATE TABLE "stg::di_sybase_amr.amr_rph_multi_dose_src"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_rph_multi_dose_src" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_rph_multi_dose_src PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_rph_src */
CREATE TABLE "stg::di_sybase_amr.amr_rph_src"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_rph_src" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_rph_src PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_rph_unit_dose_src */
CREATE TABLE "stg::di_sybase_amr.amr_rph_unit_dose_src"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_rph_unit_dose_src" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_rph_unit_dose_src PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_rpt_kit_vial_src */
CREATE TABLE "stg::di_sybase_amr.amr_rpt_kit_vial_src"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_rpt_kit_vial_src" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_rpt_kit_vial_src PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_sex */
CREATE TABLE "stg::di_sybase_amr.amr_sex"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_sex" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_sex PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_stress_mthd */
CREATE TABLE "stg::di_sybase_amr.amr_stress_mthd"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_stress_mthd" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_stress_mthd PRIMARY KEY ("id");



/* DDL FOR di_sybase_amr.AMR_stress_phrm */
CREATE TABLE "stg::di_sybase_amr.amr_stress_phrm"(
  "id" INT NOT NULL,
  "descr" NVARCHAR(255) NOT NULL
);

ALTER TABLE "stg::di_sybase_amr.amr_stress_phrm" ADD CONSTRAINT PK_stg_di_sybase_amr_amr_stress_phrm PRIMARY KEY ("id");



