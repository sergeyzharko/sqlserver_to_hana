/* DDL FOR ph_maint._036 */
ALTER TABLE "grace_qa::ph_maint._036" ADD CONSTRAINT "FK_grace_qa_ph_maint__036__036_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_maint._037 */
ALTER TABLE "grace_qa::ph_maint._037" ADD CONSTRAINT "FK_grace_qa_ph_maint__037__037_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_maint._038 */
ALTER TABLE "grace_qa::ph_maint._038" ADD CONSTRAINT "FK_grace_qa_ph_maint__038__038_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_maint._039 */
ALTER TABLE "grace_qa::ph_maint._039" ADD CONSTRAINT "FK_grace_qa_ph_maint__039__039_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_maint._040 */
ALTER TABLE "grace_qa::ph_maint._040" ADD CONSTRAINT "FK_grace_qa_ph_maint__040__040_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_maint._044 */
ALTER TABLE "grace_qa::ph_maint._044" ADD CONSTRAINT "FK_grace_qa_ph_maint__044__044_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_maint._045 */
ALTER TABLE "grace_qa::ph_maint._045" ADD CONSTRAINT "FK_grace_qa_ph_maint__045__045_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_maint._049 */
ALTER TABLE "grace_qa::ph_maint._049" ADD CONSTRAINT "FK_grace_qa_ph_maint__049__049_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;