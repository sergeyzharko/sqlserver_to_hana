/* DDL FOR ph_source._001a */
ALTER TABLE "grace_qa::ph_source._001a" ADD CONSTRAINT "FK_grace_qa_ph_source__001a__001a_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._001a" ADD CONSTRAINT "FK_grace_qa_ph_source__001a__001a_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_source._001b */
ALTER TABLE "grace_qa::ph_source._001b" ADD CONSTRAINT "FK_grace_qa_ph_source__001b__001b_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._001b" ADD CONSTRAINT "FK_grace_qa_ph_source__001b__001b_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_source._002a */
ALTER TABLE "grace_qa::ph_source._002a" ADD CONSTRAINT "FK_grace_qa_ph_source__002a__002a_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._002a" ADD CONSTRAINT "FK_grace_qa_ph_source__002a__002a_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_source._002b */
ALTER TABLE "grace_qa::ph_source._002b" ADD CONSTRAINT "FK_grace_qa_ph_source__002b__002b_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._002b" ADD CONSTRAINT "FK_grace_qa_ph_source__002b__002b_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_source._003a */
ALTER TABLE "grace_qa::ph_source._003a" ADD CONSTRAINT "FK_grace_qa_ph_source__003a__003a_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._003a" ADD CONSTRAINT "FK_grace_qa_ph_source__003a__003a_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_source._003b */
ALTER TABLE "grace_qa::ph_source._003b" ADD CONSTRAINT "FK_grace_qa_ph_source__003b__003b_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._003b" ADD CONSTRAINT "FK_grace_qa_ph_source__003b__003b_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_source._004a */
ALTER TABLE "grace_qa::ph_source._004a" ADD CONSTRAINT "FK_grace_qa_ph_source__004a__004a_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._004a" ADD CONSTRAINT "FK_grace_qa_ph_source__004a__004a_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_source._004b */
ALTER TABLE "grace_qa::ph_source._004b" ADD CONSTRAINT "FK_grace_qa_ph_source__004b__004b_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._004b" ADD CONSTRAINT "FK_grace_qa_ph_source__004b__004b_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_source._005a */
ALTER TABLE "grace_qa::ph_source._005a" ADD CONSTRAINT "FK_grace_qa_ph_source__005a__005a_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._005a" ADD CONSTRAINT "FK_grace_qa_ph_source__005a__005a_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_source._005b */
ALTER TABLE "grace_qa::ph_source._005b" ADD CONSTRAINT "FK_grace_qa_ph_source__005b__005b_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._005b" ADD CONSTRAINT "FK_grace_qa_ph_source__005b__005b_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_source._006a1 */
ALTER TABLE "grace_qa::ph_source._006a1" ADD CONSTRAINT "FK_grace_qa_ph_source__006a1__006a1_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._006a1" ADD CONSTRAINT "FK_grace_qa_ph_source__006a1__006a1_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_source._006a2 */
ALTER TABLE "grace_qa::ph_source._006a2" ADD CONSTRAINT "FK_grace_qa_ph_source__006a2__006a2_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._006a2" ADD CONSTRAINT "FK_grace_qa_ph_source__006a2__006a2_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_source._006b */
ALTER TABLE "grace_qa::ph_source._006b" ADD CONSTRAINT "FK_grace_qa_ph_source__006b__006b_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._006b" ADD CONSTRAINT "FK_grace_qa_ph_source__006b__006b_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_source._007 */
ALTER TABLE "grace_qa::ph_source._007" ADD CONSTRAINT "FK_grace_qa_ph_source__007__007_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._007" ADD CONSTRAINT "FK_grace_qa_ph_source__007__007_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_source._008 */
ALTER TABLE "grace_qa::ph_source._008" ADD CONSTRAINT "FK_grace_qa_ph_source__008__008_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._008" ADD CONSTRAINT "FK_grace_qa_ph_source__008__008_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_source._009 */
ALTER TABLE "grace_qa::ph_source._009" ADD CONSTRAINT "FK_grace_qa_ph_source__009__009_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._009" ADD CONSTRAINT "FK_grace_qa_ph_source__009__009_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_source._010 */
ALTER TABLE "grace_qa::ph_source._010" ADD CONSTRAINT "FK_grace_qa_ph_source__010__010_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._010" ADD CONSTRAINT "FK_grace_qa_ph_source__010__010_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_source._011 */
ALTER TABLE "grace_qa::ph_source._011" ADD CONSTRAINT "FK_grace_qa_ph_source__011__011_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_source._011" ADD CONSTRAINT "FK_grace_qa_ph_source__011__011_source_id" FOREIGN KEY ("source_id") REFERENCES "grace_qa::ph_md.sources"("source_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
