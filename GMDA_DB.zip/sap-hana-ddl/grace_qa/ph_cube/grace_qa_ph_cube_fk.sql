/* DDL FOR ph_cube._015 */
ALTER TABLE "grace_qa::ph_cube._015" ADD CONSTRAINT "FK_grace_qa_ph_cube__015__015_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_cube._015" ADD CONSTRAINT "FK_grace_qa_ph_cube__015__015_cube_id" FOREIGN KEY ("cube_id") REFERENCES "grace_qa::ph_md.cubes"("cube_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_cube._016 */
ALTER TABLE "grace_qa::ph_cube._016" ADD CONSTRAINT "FK_grace_qa_ph_cube__016__016_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_cube._016" ADD CONSTRAINT "FK_grace_qa_ph_cube__016__016_cube_id" FOREIGN KEY ("cube_id") REFERENCES "grace_qa::ph_md.cubes"("cube_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_cube._017 */
ALTER TABLE "grace_qa::ph_cube._017" ADD CONSTRAINT "FK_grace_qa_ph_cube__017__017_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_cube._017" ADD CONSTRAINT "FK_grace_qa_ph_cube__017__017_cube_id" FOREIGN KEY ("cube_id") REFERENCES "grace_qa::ph_md.cubes"("cube_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_cube._018a */
ALTER TABLE "grace_qa::ph_cube._018a" ADD CONSTRAINT "FK_grace_qa_ph_cube__018a__018a_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_cube._018a" ADD CONSTRAINT "FK_grace_qa_ph_cube__018a__018a_cube_id" FOREIGN KEY ("cube_id") REFERENCES "grace_qa::ph_md.cubes"("cube_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_cube._018b */
ALTER TABLE "grace_qa::ph_cube._018b" ADD CONSTRAINT "FK_grace_qa_ph_cube__018b__018b_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_cube._018b" ADD CONSTRAINT "FK_grace_qa_ph_cube__018b__018b_cube_id" FOREIGN KEY ("cube_id") REFERENCES "grace_qa::ph_md.cubes"("cube_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_cube._019a */
ALTER TABLE "grace_qa::ph_cube._019a" ADD CONSTRAINT "FK_grace_qa_ph_cube__019a__019a_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_cube._019a" ADD CONSTRAINT "FK_grace_qa_ph_cube__019a__019a_cube_id" FOREIGN KEY ("cube_id") REFERENCES "grace_qa::ph_md.cubes"("cube_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_cube._019b */
ALTER TABLE "grace_qa::ph_cube._019b" ADD CONSTRAINT "FK_grace_qa_ph_cube__019b__019b_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_cube._019b" ADD CONSTRAINT "FK_grace_qa_ph_cube__019b__019b_cube_id" FOREIGN KEY ("cube_id") REFERENCES "grace_qa::ph_md.cubes"("cube_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_cube._020 */
ALTER TABLE "grace_qa::ph_cube._020" ADD CONSTRAINT "FK_grace_qa_ph_cube__020__020_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_cube._020" ADD CONSTRAINT "FK_grace_qa_ph_cube__020__020_cube_id" FOREIGN KEY ("cube_id") REFERENCES "grace_qa::ph_md.cubes"("cube_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_cube._021 */
ALTER TABLE "grace_qa::ph_cube._021" ADD CONSTRAINT "FK_grace_qa_ph_cube__021__021_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_cube._021" ADD CONSTRAINT "FK_grace_qa_ph_cube__021__021_cube_id" FOREIGN KEY ("cube_id") REFERENCES "grace_qa::ph_md.cubes"("cube_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_cube._024 */
ALTER TABLE "grace_qa::ph_cube._024" ADD CONSTRAINT "FK_grace_qa_ph_cube__024__024_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_cube._024" ADD CONSTRAINT "FK_grace_qa_ph_cube__024__024_cube_id" FOREIGN KEY ("cube_id") REFERENCES "grace_qa::ph_md.cubes"("cube_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_cube._030 */
ALTER TABLE "grace_qa::ph_cube._030" ADD CONSTRAINT "FK_grace_qa_ph_cube__030__030_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_cube._030" ADD CONSTRAINT "FK_grace_qa_ph_cube__030__030_cube_id" FOREIGN KEY ("cube_id") REFERENCES "grace_qa::ph_md.cubes"("cube_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_cube._031 */
ALTER TABLE "grace_qa::ph_cube._031" ADD CONSTRAINT "FK_grace_qa_ph_cube__031__031_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_cube._031" ADD CONSTRAINT "FK_grace_qa_ph_cube__031__031_cube_id" FOREIGN KEY ("cube_id") REFERENCES "grace_qa::ph_md.cubes"("cube_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_cube._033 */
ALTER TABLE "grace_qa::ph_cube._033" ADD CONSTRAINT "FK_grace_qa_ph_cube__033__033_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_cube._033" ADD CONSTRAINT "FK_grace_qa_ph_cube__033__033_cube_id" FOREIGN KEY ("cube_id") REFERENCES "grace_qa::ph_md.cubes"("cube_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR ph_cube._034 */
ALTER TABLE "grace_qa::ph_cube._034" ADD CONSTRAINT "FK_grace_qa_ph_cube__034__034_update_period" FOREIGN KEY ("update_period") REFERENCES "grace_qa::ph_md.periods"("period_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "grace_qa::ph_cube._034" ADD CONSTRAINT "FK_grace_qa_ph_cube__034__034_cube_id" FOREIGN KEY ("cube_id") REFERENCES "grace_qa::ph_md.cubes"("cube_id") ON DELETE RESTRICT ON UPDATE RESTRICT;