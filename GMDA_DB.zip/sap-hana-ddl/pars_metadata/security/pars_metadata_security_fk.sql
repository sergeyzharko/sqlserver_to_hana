/* DDL FOR security.group_permission */
ALTER TABLE "pars_metadata::security.group_permission" ADD CONSTRAINT "FK_pars_metadata_security_group_permission_group_permission_group_id" FOREIGN KEY ("group_id") REFERENCES "pars_metadata::security.pars_group"("group_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "pars_metadata::security.group_permission" ADD CONSTRAINT "FK_pars_metadata_security_group_permission_group_permission_permission_id" FOREIGN KEY ("permission_id") REFERENCES "pars_metadata::security.permission"("permission_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR security.last_password */
ALTER TABLE "pars_metadata::security.last_password" ADD CONSTRAINT "FK_pars_metadata_security_last_password_last_password_user_id" FOREIGN KEY ("user_id") REFERENCES "pars_metadata::security.pars_user"("user_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR security.user_group */
ALTER TABLE "pars_metadata::security.user_group" ADD CONSTRAINT "FK_pars_metadata_security_user_group_user_group_group_id" FOREIGN KEY ("group_id") REFERENCES "pars_metadata::security.pars_group"("group_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "pars_metadata::security.user_group" ADD CONSTRAINT "FK_pars_metadata_security_user_group_user_group_user_id" FOREIGN KEY ("user_id") REFERENCES "pars_metadata::security.pars_user"("user_id") ON DELETE RESTRICT ON UPDATE RESTRICT;

/* DDL FOR security.user_property */
ALTER TABLE "pars_metadata::security.user_property" ADD CONSTRAINT "FK_pars_metadata_security_user_property_user_property_user_id" FOREIGN KEY ("user_id") REFERENCES "pars_metadata::security.pars_user"("user_id") ON DELETE RESTRICT ON UPDATE RESTRICT;