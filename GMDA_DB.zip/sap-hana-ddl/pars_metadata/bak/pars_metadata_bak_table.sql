/* DDL FOR bak.G987_ERDDT_repository__conflicting_jobs_20190405 */
CREATE TABLE "pars_metadata::bak.g987_erddt_repository__conflicting_jobs_20190405"(
  "first_process_id" INT NOT NULL,
  "second_process_id" INT NOT NULL
);