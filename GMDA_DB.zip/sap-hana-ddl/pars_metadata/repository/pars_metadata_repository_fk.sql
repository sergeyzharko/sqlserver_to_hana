/* DDL FOR repository.batch_job_job_list */
ALTER TABLE "pars_metadata::repository.batch_job_job_list" ADD CONSTRAINT "FK_pars_metadata_repository_batch_job_job_list_batch_job_job_list_batch_job_id" FOREIGN KEY ("batch_job_id") REFERENCES "pars_metadata::repository.publish_process"("publish_process_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "pars_metadata::repository.batch_job_job_list" ADD CONSTRAINT "FK_pars_metadata_repository_batch_job_job_list_batch_job_job_list_job_id" FOREIGN KEY ("job_id") REFERENCES "pars_metadata::repository.publish_process"("publish_process_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR repository.conflicting_job_maintenance */
ALTER TABLE "pars_metadata::repository.conflicting_job_maintenance" ADD CONSTRAINT "FK_pars_metadata_repository_conflicting_job_maintenance_conflicting_job_maintenance_maintenance_id" FOREIGN KEY ("maintenance_id") REFERENCES "pars_metadata::repository.maintenance"("maintenance_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "pars_metadata::repository.conflicting_job_maintenance" ADD CONSTRAINT "FK_pars_metadata_repository_conflicting_job_maintenance_conflicting_job_maintenance_process_id" FOREIGN KEY ("process_id") REFERENCES "pars_metadata::repository.publish_process"("publish_process_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR repository.conflicting_jobs */
ALTER TABLE "pars_metadata::repository.conflicting_jobs" ADD CONSTRAINT "FK_pars_metadata_repository_conflicting_jobs_conflicting_jobs_first_process_id" FOREIGN KEY ("first_process_id") REFERENCES "pars_metadata::repository.publish_process"("publish_process_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "pars_metadata::repository.conflicting_jobs" ADD CONSTRAINT "FK_pars_metadata_repository_conflicting_jobs_conflicting_jobs_second_process_id" FOREIGN KEY ("second_process_id") REFERENCES "pars_metadata::repository.publish_process"("publish_process_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR repository.folder */
ALTER TABLE "pars_metadata::repository.folder" ADD CONSTRAINT "FK_pars_metadata_repository_folder_folder_parent_folder_id" FOREIGN KEY ("parent_folder_id") REFERENCES "pars_metadata::repository.folder"("folder_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "pars_metadata::repository.folder" ADD CONSTRAINT "FK_pars_metadata_repository_folder_folder_home_folder_of_user_id" FOREIGN KEY ("home_folder_of_user_id") REFERENCES "pars_metadata::security.pars_user"("user_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR repository.folder_permission */
ALTER TABLE "pars_metadata::repository.folder_permission" ADD CONSTRAINT "FK_pars_metadata_repository_folder_permission_folder_permission_folder_id" FOREIGN KEY ("folder_id") REFERENCES "pars_metadata::repository.folder"("folder_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "pars_metadata::repository.folder_permission" ADD CONSTRAINT "FK_pars_metadata_repository_folder_permission_folder_permission_group_id" FOREIGN KEY ("group_id") REFERENCES "pars_metadata::security.pars_group"("group_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR repository.format_use */
ALTER TABLE "pars_metadata::repository.format_use" ADD CONSTRAINT "FK_pars_metadata_repository_format_use_format_use_format_object_id" FOREIGN KEY ("format_object_id") REFERENCES "pars_metadata::repository.format"("format_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "pars_metadata::repository.format_use" ADD CONSTRAINT "FK_pars_metadata_repository_format_use_format_use_query_object_id" FOREIGN KEY ("query_object_id") REFERENCES "pars_metadata::repository.repository_object"("object_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR repository.grouping_use */
ALTER TABLE "pars_metadata::repository.grouping_use" ADD CONSTRAINT "FK_pars_metadata_repository_grouping_use_grouping_use_grouping_object_id" FOREIGN KEY ("grouping_object_id") REFERENCES "pars_metadata::repository.repository_object"("object_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "pars_metadata::repository.grouping_use" ADD CONSTRAINT "FK_pars_metadata_repository_grouping_use_grouping_use_query_object_id" FOREIGN KEY ("query_object_id") REFERENCES "pars_metadata::repository.repository_object"("object_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR repository.job_parameter */
ALTER TABLE "pars_metadata::repository.job_parameter" ADD CONSTRAINT "FK_pars_metadata_repository_job_parameter_job_parameter_publish_process_id" FOREIGN KEY ("publish_process_id") REFERENCES "pars_metadata::repository.publish_process"("publish_process_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR repository.job_step_history */
ALTER TABLE "pars_metadata::repository.job_step_history" ADD CONSTRAINT "FK_pars_metadata_repository_job_step_history_job_step_history_job_history_id" FOREIGN KEY ("job_history_id") REFERENCES "pars_metadata::repository.job_history"("job_history_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR repository.maintenance_log */
ALTER TABLE "pars_metadata::repository.maintenance_log" ADD CONSTRAINT "FK_pars_metadata_repository_maintenance_log_maintenance_log_maintenance_id" FOREIGN KEY ("maintenance_id") REFERENCES "pars_metadata::repository.maintenance"("maintenance_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR repository.object_permission */
ALTER TABLE "pars_metadata::repository.object_permission" ADD CONSTRAINT "FK_pars_metadata_repository_object_permission_object_permission_group_id" FOREIGN KEY ("group_id") REFERENCES "pars_metadata::security.pars_group"("group_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "pars_metadata::repository.object_permission" ADD CONSTRAINT "FK_pars_metadata_repository_object_permission_object_permission_object_id" FOREIGN KEY ("object_id") REFERENCES "pars_metadata::repository.repository_object"("object_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR repository.process_to_maintenance */
ALTER TABLE "pars_metadata::repository.process_to_maintenance" ADD CONSTRAINT "FK_pars_metadata_repository_process_to_maintenance_process_to_maintenance_maintenance_id" FOREIGN KEY ("maintenance_id") REFERENCES "pars_metadata::repository.maintenance"("maintenance_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "pars_metadata::repository.process_to_maintenance" ADD CONSTRAINT "FK_pars_metadata_repository_process_to_maintenance_process_to_maintenance_publish_process_id" FOREIGN KEY ("publish_process_id") REFERENCES "pars_metadata::repository.publish_process"("publish_process_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR repository.repository_object */
ALTER TABLE "pars_metadata::repository.repository_object" ADD CONSTRAINT "FK_pars_metadata_repository_repository_object_repository_object_object_folder_id" FOREIGN KEY ("object_folder_id") REFERENCES "pars_metadata::repository.folder"("folder_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "pars_metadata::repository.repository_object" ADD CONSTRAINT "FK_pars_metadata_repository_repository_object_repository_object_parent_grouping_object_id" FOREIGN KEY ("parent_grouping_object_id") REFERENCES "pars_metadata::repository.repository_object"("object_id") ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE "pars_metadata::repository.repository_object" ADD CONSTRAINT "FK_pars_metadata_repository_repository_object_repository_object_filter_object_id" FOREIGN KEY ("filter_object_id") REFERENCES "pars_metadata::repository.repository_object"("object_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



/* DDL FOR repository.script_execution_detail */
ALTER TABLE "pars_metadata::repository.script_execution_detail" ADD CONSTRAINT "FK_pars_metadata_repository_script_execution_detail_script_execution_detail_script_execution_log_id" FOREIGN KEY ("script_execution_log_id") REFERENCES "pars_metadata::repository.script_execution_log"("script_execution_log_id") ON DELETE RESTRICT ON UPDATE RESTRICT;



