# Microsoft SQL DDL to HANA 2.0 CDS

Запуск:
1. npm i (для установки архиватора).
2. node sqlhana input output, где "input" - папка со скриптами mssql, "output" - папка для hana скриптов. По умолчанию применяются значения: "sap-hana-ddl" и "src".

В папке с программой создаётся готовый ZIP архив для импорта в SAP HANA 2.0.